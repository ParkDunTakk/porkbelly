import { createClient } from '@supabase/supabase-js';
import { projectId, publicAnonKey } from './info';

// Supabase 클라이언트 싱글톤
export const supabase = createClient(
  `https://${projectId}.supabase.co`,
  publicAnonKey
);

// 서버 API 기본 URL
export const API_URL = `https://${projectId}.supabase.co/functions/v1/make-server-3f0775df`;

// API 헬퍼 함수
export async function apiCall(endpoint: string, options: RequestInit = {}) {
  const { data: { session } } = await supabase.auth.getSession();
  
  const headers: HeadersInit = {
    'Content-Type': 'application/json',
    ...options.headers,
  };

  if (session?.access_token) {
    headers['Authorization'] = `Bearer ${session.access_token}`;
  } else {
    headers['Authorization'] = `Bearer ${publicAnonKey}`;
  }

  const response = await fetch(`${API_URL}${endpoint}`, {
    ...options,
    headers,
  });

  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.error || 'API 호출 실패');
  }

  return response.json();
}
