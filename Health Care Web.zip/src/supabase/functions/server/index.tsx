import { Hono } from 'npm:hono';
import { cors } from 'npm:hono/cors';
import { logger } from 'npm:hono/logger';
import { createClient } from 'npm:@supabase/supabase-js@2';
import * as kv from './kv_store.tsx';

const app = new Hono();

// Middleware
app.use('*', cors());
app.use('*', logger(console.log));

// Supabase 클라이언트 생성
const getSupabaseClient = () => {
  return createClient(
    Deno.env.get('SUPABASE_URL') ?? '',
    Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
  );
};

// 데이터베이스 초기화
async function initializeDatabase() {
  const supabase = getSupabaseClient();
  
  console.log('🔧 HealCat 데이터베이스 초기화 중...');
  
  try {
    // KV Store를 사용해서 테이블 생성 (간단한 방식)
    // 실제 Postgres 테이블은 Supabase UI에서 생성해야 하지만,
    // 여기서는 KV Store로 임시 저장소 사용
    
    // 초기 배지 데이터 생성
    const badges = [
      { id: '1', name: '첫 걸음', description: '첫 번째 운동 완료', icon: '🎯', condition: 'Complete first workout' },
      { id: '2', name: '일주일 챌린저', description: '7일 연속 활동 기록', icon: '🔥', condition: '7 day streak' },
      { id: '3', name: '수분 마스터', description: '하루 물 8잔 달성', icon: '💧', condition: 'Drink 8 glasses of water' },
      { id: '4', name: '얼리버드', description: '아침 운동 10회 완료', icon: '🌅', condition: '10 morning workouts' },
      { id: '5', name: '철인', description: '30일 연속 운동', icon: '💪', condition: '30 day workout streak' },
      { id: '6', name: '건강 달인', description: '100회 운동 완료', icon: '👑', condition: 'Complete 100 workouts' },
    ];
    
    const existingBadges = await kv.get('badges_list');
    if (!existingBadges) {
      await kv.set('badges_list', badges);
      console.log('✅ 초기 배지 데이터 생성 완료');
    }
    
    console.log('✅ HealCat 데이터베이스 준비 완료!');
  } catch (error) {
    console.log('⚠️ 데이터베이스 초기화 중 에러:', error);
  }
}

// 서버 시작 시 초기화
initializeDatabase();

// 🔐 회원가입 API
app.post('/make-server-3f0775df/auth/signup', async (c) => {
  try {
    const { email, password, name } = await c.req.json();

    if (!email || !password) {
      return c.json({ error: 'Email and password are required' }, 400);
    }

    const supabase = getSupabaseClient();

    // 사용자 생성
    const { data: authData, error: authError } = await supabase.auth.admin.createUser({
      email,
      password,
      user_metadata: { name: name || 'HealCat User' },
      email_confirm: true, // 이메일 확인 자동 승인 (메일 서버 미설정)
    });

    if (authError) {
      console.log('회원가입 에러:', authError);
      return c.json({ error: authError.message }, 400);
    }

    // KV Store에 사용자 프로필 초기화
    await kv.set(`user_profile:${authData.user.id}`, {
      id: authData.user.id,
      email: email,
      name: name || 'HealCat User',
      level: 1,
      xp: 0,
      total_points: 0,
      streak: 0,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    });

    console.log('✅ 회원가입 성공:', authData.user.email);

    return c.json({ 
      success: true, 
      user: authData.user,
      message: '회원가입이 완료되었습니다!' 
    });
  } catch (error) {
    console.log('회원가입 처리 중 에러:', error);
    return c.json({ error: error instanceof Error ? error.message : 'Unknown error' }, 500);
  }
});

// 👤 사용자 프로필 조회
app.get('/make-server-3f0775df/profile', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    if (!accessToken) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const supabase = getSupabaseClient();
    const { data: { user }, error: userError } = await supabase.auth.getUser(accessToken);

    if (userError || !user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    // KV Store에서 프로필 조회
    const profile = await kv.get(`user_profile:${user.id}`);

    if (!profile) {
      // 프로필이 없으면 기본 프로필 생성
      const newProfile = {
        id: user.id,
        email: user.email,
        name: user.user_metadata?.name || 'HealCat User',
        level: 1,
        xp: 0,
        total_points: 0,
        streak: 0,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      };
      await kv.set(`user_profile:${user.id}`, newProfile);
      return c.json({ profile: newProfile });
    }

    return c.json({ profile });
  } catch (error) {
    console.log('프로필 조회 중 에러:', error);
    return c.json({ error: error instanceof Error ? error.message : 'Unknown error' }, 500);
  }
});

// 📝 사용자 프로필 업데이트 (온보딩 데이터 포함)
app.put('/make-server-3f0775df/profile', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    if (!accessToken) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const supabase = getSupabaseClient();
    const { data: { user }, error: userError } = await supabase.auth.getUser(accessToken);

    if (userError || !user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const profileData = await c.req.json();

    // 기존 프로필 가져오기
    const existingProfile = await kv.get(`user_profile:${user.id}`) || {};

    // 업데이트된 프로필
    const updatedProfile = {
      ...existingProfile,
      ...profileData,
      id: user.id,
      updated_at: new Date().toISOString(),
    };

    await kv.set(`user_profile:${user.id}`, updatedProfile);

    console.log('✅ 프로필 업데이트 성공:', user.email);

    return c.json({ profile: updatedProfile, message: '프로필이 업데이트되었습니다!' });
  } catch (error) {
    console.log('프로필 업데이트 중 에러:', error);
    return c.json({ error: error instanceof Error ? error.message : 'Unknown error' }, 500);
  }
});

// 📊 일일 활동 저장/업데이트
app.post('/make-server-3f0775df/daily-activity', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    if (!accessToken) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const supabase = getSupabaseClient();
    const { data: { user }, error: userError } = await supabase.auth.getUser(accessToken);

    if (userError || !user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const activityData = await c.req.json();
    const today = new Date().toISOString().split('T')[0];

    // KV Store에 저장
    const activityKey = `activity:${user.id}:${today}`;
    const activity = {
      user_id: user.id,
      date: today,
      ...activityData,
      created_at: new Date().toISOString(),
    };

    await kv.set(activityKey, activity);

    // 연속 일수 업데이트
    await updateStreakKV(user.id);

    console.log('✅ 일일 활동 저장 성공:', user.email, today);

    return c.json({ activity, message: '활동이 저장되었습니다!' });
  } catch (error) {
    console.log('일일 활동 저장 중 에러:', error);
    return c.json({ error: error instanceof Error ? error.message : 'Unknown error' }, 500);
  }
});

// 📊 일일 활동 조회 (특정 날짜)
app.get('/make-server-3f0775df/daily-activity/:date', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    if (!accessToken) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const supabase = getSupabaseClient();
    const { data: { user }, error: userError } = await supabase.auth.getUser(accessToken);

    if (userError || !user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const date = c.req.param('date');
    const activityKey = `activity:${user.id}:${date}`;
    
    const activity = await kv.get(activityKey);

    return c.json({ activity: activity || null });
  } catch (error) {
    console.log('활동 조회 중 에러:', error);
    return c.json({ error: error instanceof Error ? error.message : 'Unknown error' }, 500);
  }
});

// 📈 주간 활동 조회
app.get('/make-server-3f0775df/weekly-activities', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    if (!accessToken) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const supabase = getSupabaseClient();
    const { data: { user }, error: userError } = await supabase.auth.getUser(accessToken);

    if (userError || !user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    // 최근 7일 데이터 조회
    const activities = [];
    for (let i = 6; i >= 0; i--) {
      const date = new Date();
      date.setDate(date.getDate() - i);
      const dateStr = date.toISOString().split('T')[0];
      
      const activity = await kv.get(`activity:${user.id}:${dateStr}`);
      if (activity) {
        activities.push(activity);
      }
    }

    // 평균 계산
    const totalDays = activities.length;
    const averages = totalDays > 0 ? {
      water: activities.reduce((sum: number, a: any) => sum + (a.water_glasses || 0), 0) / totalDays,
      sleep: activities.reduce((sum: number, a: any) => sum + (a.sleep_hours || 0), 0) / totalDays,
      caloriesIntake: activities.reduce((sum: number, a: any) => sum + (a.calories_intake || 0), 0) / totalDays,
      caloriesBurned: activities.reduce((sum: number, a: any) => sum + (a.calories_burned || 0), 0) / totalDays,
      steps: activities.reduce((sum: number, a: any) => sum + (a.steps || 0), 0) / totalDays,
    } : {
      water: 0,
      sleep: 0,
      caloriesIntake: 0,
      caloriesBurned: 0,
      steps: 0,
    };

    return c.json({ 
      activities,
      averages,
      totalDays 
    });
  } catch (error) {
    console.log('주간 활동 조회 중 에러:', error);
    return c.json({ error: error instanceof Error ? error.message : 'Unknown error' }, 500);
  }
});

// 🏆 배지 목록 조회
app.get('/make-server-3f0775df/badges', async (c) => {
  try {
    const badges = await kv.get('badges_list') || [];
    return c.json({ badges });
  } catch (error) {
    console.log('배지 조회 중 에러:', error);
    return c.json({ error: error instanceof Error ? error.message : 'Unknown error' }, 500);
  }
});

// 🏆 사용자 배지 조회
app.get('/make-server-3f0775df/user-badges', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    if (!accessToken) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const supabase = getSupabaseClient();
    const { data: { user }, error: userError } = await supabase.auth.getUser(accessToken);

    if (userError || !user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const userBadges = await kv.get(`user_badges:${user.id}`) || [];
    return c.json({ userBadges });
  } catch (error) {
    console.log('사용자 배지 조회 중 에러:', error);
    return c.json({ error: error instanceof Error ? error.message : 'Unknown error' }, 500);
  }
});

// 🎯 포인트 증가
app.post('/make-server-3f0775df/add-points', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    if (!accessToken) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const supabase = getSupabaseClient();
    const { data: { user }, error: userError } = await supabase.auth.getUser(accessToken);

    if (userError || !user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const { points } = await c.req.json();

    // 현재 프로필 조회
    const profile = await kv.get(`user_profile:${user.id}`);

    if (!profile) {
      return c.json({ error: 'Profile not found' }, 404);
    }

    const newXP = (profile.xp || 0) + points;
    const newTotalPoints = (profile.total_points || 0) + points;
    
    // 레벨 업 계산 (100 XP당 1레벨)
    const newLevel = Math.floor(newXP / 100) + 1;

    const updatedProfile = {
      ...profile,
      xp: newXP,
      total_points: newTotalPoints,
      level: newLevel,
      updated_at: new Date().toISOString(),
    };

    await kv.set(`user_profile:${user.id}`, updatedProfile);

    return c.json({ 
      profile: updatedProfile,
      leveledUp: newLevel > (profile.level || 1),
      message: `${points} 포인트를 획득했습니다!` 
    });
  } catch (error) {
    console.log('포인트 추가 중 에러:', error);
    return c.json({ error: error instanceof Error ? error.message : 'Unknown error' }, 500);
  }
});

// 🔥 연속 일수 업데이트 헬퍼 함수 (KV Store용)
async function updateStreakKV(userId: string) {
  try {
    const today = new Date().toISOString().split('T')[0];
    const yesterday = new Date(Date.now() - 86400000).toISOString().split('T')[0];

    const todayActivity = await kv.get(`activity:${userId}:${today}`);
    const yesterdayActivity = await kv.get(`activity:${userId}:${yesterday}`);

    const profile = await kv.get(`user_profile:${userId}`);
    
    if (!profile) return;

    let newStreak = 1;

    if (todayActivity && yesterdayActivity) {
      // 연속
      newStreak = (profile.streak || 0) + 1;
    }

    await kv.set(`user_profile:${userId}`, {
      ...profile,
      streak: newStreak,
    });
  } catch (error) {
    console.log('연속 일수 업데이트 에러:', error);
  }
}

// 🤖 OpenAI 챗 API
app.post('/make-server-3f0775df/chat', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    if (!accessToken) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const supabase = getSupabaseClient();
    const { data: { user }, error: userError } = await supabase.auth.getUser(accessToken);

    if (userError || !user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const { message, history } = await c.req.json();

    if (!message) {
      return c.json({ error: 'Message is required' }, 400);
    }

    // OpenAI API 키 확인
    const apiKey = Deno.env.get('OPENAI_API_KEY');
    if (!apiKey) {
      return c.json({ error: 'OpenAI API key not configured' }, 500);
    }

    // 사용자 프로필 조회 (전체 온보딩 정보)
    const profile = await kv.get(`user_profile:${user.id}`);
    const today = new Date().toISOString().split('T')[0];
    const todayActivity = await kv.get(`activity:${user.id}:${today}`);

    // 📊 사용자 선호도 데이터 조회 (학습된 데이터)
    const userPreferences = await kv.get(`user_preferences:${user.id}`) || {
      preferred_topics: [],
      preferred_exercise_types: [],
      disliked_exercise_types: [],
      preferred_response_style: null,
    };

    // 🔍 오늘의 건강 상태 분석
    const healthChecks = {
      water: {
        current: todayActivity?.water_glasses || 0,
        goal: 8,
        status: (todayActivity?.water_glasses || 0) >= 8 ? 'good' : (todayActivity?.water_glasses || 0) >= 5 ? 'ok' : 'low'
      },
      sleep: {
        current: todayActivity?.sleep_hours || 0,
        goal: 7,
        status: (todayActivity?.sleep_hours || 0) >= 7 && (todayActivity?.sleep_hours || 0) <= 9 ? 'good' : (todayActivity?.sleep_hours || 0) < 7 ? 'low' : 'high'
      },
      meals: {
        current: todayActivity?.meals_completed || 0,
        goal: 3,
        breakfast: todayActivity?.breakfast || false,
        lunch: todayActivity?.lunch || false,
        dinner: todayActivity?.dinner || false,
        status: (todayActivity?.meals_completed || 0) >= 3 ? 'good' : (todayActivity?.meals_completed || 0) >= 2 ? 'ok' : 'low'
      },
      mood: todayActivity?.mood || 'okay'
    };

    // ⚠️ 부족한 항목 체크
    const deficiencies = [];
    if (healthChecks.water.status === 'low') {
      deficiencies.push(`수분 섭취 부족 (${healthChecks.water.current}/${healthChecks.water.goal}잔)`);
    }
    if (healthChecks.sleep.status === 'low') {
      deficiencies.push(`수면 시간 부족 (${healthChecks.sleep.current}시간, 권장: 7-9시간)`);
    }
    if (healthChecks.meals.status === 'low') {
      const missedMeals = [];
      if (!healthChecks.meals.breakfast) missedMeals.push('아침');
      if (!healthChecks.meals.lunch) missedMeals.push('점심');
      if (!healthChecks.meals.dinner) missedMeals.push('저녁');
      deficiencies.push(`식사 기록 부족 (완료: ${healthChecks.meals.current}/3, 미완료: ${missedMeals.join(', ')})`);
    }

    // 📊 상세 개인화 컨텍스트 구성
    const userContext = {
      // 기본 정보
      gender: profile?.gender || '미설정',
      height: profile?.height || '미설정',
      weight: profile?.weight || '미설정',
      bmi: profile?.bmi || '미설정',
      bodyType: profile?.bodyType || '미설정',
      
      // 목표 & 관심사
      goal: profile?.goal || '미설정',
      interests: profile?.interests || [],
      exerciseTypes: profile?.exerciseTypes || [],
      
      // 신체 정보
      focusAreas: profile?.focusAreas || [],
      injuries: profile?.injuries || '없음',
      
      // 라이프스타일
      lifestyleActivity: profile?.lifestyleActivity || '미설정',
      energyLevel: profile?.energyLevel || 5,
      weeklyWorkouts: profile?.weeklyWorkouts || 3,
      
      // 현재 상태
      pushups: profile?.pushups || 0,
      walkingTime: profile?.walkingTime || 30,
      sleepTime: profile?.sleepTime || 7,
      
      // 식습관
      dietType: profile?.dietType || '미설정',
      badHabits: profile?.badHabits || [],
      
      // 성격
      mbti: profile?.mbti || '미설정',
      personality: profile?.personality || '미설정',
      
      // 오늘의 상태 (일일 추적 데이터)
      todayMood: todayActivity?.mood || '보통',
      todayWater: todayActivity?.water_glasses || 0,
      todaySleep: todayActivity?.sleep_hours || 0,
      todayMeals: todayActivity?.meals_completed || 0,
      todayBreakfast: todayActivity?.breakfast || false,
      todayLunch: todayActivity?.lunch || false,
      todayDinner: todayActivity?.dinner || false,
      
      // 🧠 학습된 선호도 (NEW!)
      preferredTopics: userPreferences.preferred_topics,
      preferredExercises: userPreferences.preferred_exercise_types,
      dislikedExercises: userPreferences.disliked_exercise_types,
      preferredStyle: userPreferences.preferred_response_style,
      
      // ⚠️ 오늘의 건강 체크
      healthChecks: healthChecks,
      deficiencies: deficiencies,
    };

    // 🧠 학습된 선호도 섹션 생성
    let preferencesSection = '';
    if (userPreferences.preferred_exercise_types.length > 0 || userPreferences.disliked_exercise_types.length > 0) {
      preferencesSection = `\n\n## 🧠 학습된 사용자 선호도 (최우선 고려!)\n`;
      
      if (userPreferences.preferred_exercise_types.length > 0) {
        preferencesSection += `\n✅ **선호하는 운동:** ${userPreferences.preferred_exercise_types.join(', ')}\n   → 이 운동들을 우선적으로 추천하세요!\n`;
      }
      
      if (userPreferences.disliked_exercise_types.length > 0) {
        preferencesSection += `\n❌ **선호하지 않는 운동:** ${userPreferences.disliked_exercise_types.join(', ')}\n   → 이 운동들은 피하고 대안을 제시하세요!\n`;
      }
      
      if (userPreferences.preferred_topics.length > 0) {
        preferencesSection += `\n💬 **관심 주제:** ${userPreferences.preferred_topics.join(', ')}\n`;
      }
      
      if (userPreferences.preferred_response_style) {
        preferencesSection += `\n📝 **선호 답변 스타일:** ${userPreferences.preferred_response_style}\n`;
      }
    }

    // 감정 & 개인화 기반 시스템 프롬프트
    const systemPrompt = `당신은 HealCat, 감정과 상황을 깊이 이해하는 초개인화 건강 어시스턴트입니다. 🐱

## 📋 사용자 프로필 (매우 중요!)

**기본 정보:**
- 성별: ${userContext.gender}
- 키/체중: ${userContext.height}cm / ${userContext.weight}kg (BMI: ${userContext.bmi})
- 체형: ${userContext.bodyType}

**목표 & 관심사:**
- 주요 목표: ${userContext.goal}
- 관심 분야: ${userContext.interests.length > 0 ? userContext.interests.join(', ') : '미설정'}
- 선호 운동: ${userContext.exerciseTypes.length > 0 ? userContext.exerciseTypes.join(', ') : '미설정'}

**신체 정보:**
- 집중 부위: ${userContext.focusAreas.length > 0 ? userContext.focusAreas.join(', ') : '전체'}
- 부상/제한: ${userContext.injuries}

**라이프스타일:**
- 활동 수준: ${userContext.lifestyleActivity}
- 에너지 레벨: ${userContext.energyLevel}/10
- 주간 운동 횟수: ${userContext.weeklyWorkouts}회

**현재 체력:**
- 팔굽혀펴기: ${userContext.pushups}개
- 걷기 시간: ${userContext.walkingTime}분/일
- 수면: ${userContext.sleepTime}시간

**식습관:**
- 식단 유형: ${userContext.dietType}
- 개선할 습관: ${userContext.badHabits.length > 0 ? userContext.badHabits.join(', ') : '없음'}

**성격:**
- MBTI: ${userContext.mbti}
- 운동 성격: ${userContext.personality}

## 📊 오늘의 일일 추적 데이터 (실시간 반영!)

**오늘 기분:** ${userContext.todayMood === 'great' ? '좋아요 😊' : userContext.todayMood === 'tired' ? '피곤해요 😔' : '보통 😐'}
**수분 섭취:** ${userContext.todayWater}잔 / 8잔 목표 ${healthChecks.water.status === 'good' ? '✅' : healthChecks.water.status === 'ok' ? '⚠️' : '❌'}
**수면 시간:** ${userContext.todaySleep}시간 ${healthChecks.sleep.status === 'good' ? '✅' : healthChecks.sleep.status === 'low' ? '❌ (부족)' : '⚠️ (과다)'}
**식사 기록:**
  - 아침: ${userContext.todayBreakfast ? '✅' : '❌'}
  - 점심: ${userContext.todayLunch ? '✅' : '❌'}
  - 저녁: ${userContext.todayDinner ? '✅' : '❌'}
  - 완료: ${userContext.todayMeals}/3 ${healthChecks.meals.status === 'good' ? '✅' : '⚠️'}

${deficiencies.length > 0 ? `\n## ⚠️ 오늘 부족한 부분\n${deficiencies.map(d => `- ${d}`).join('\n')}\n` : ''}
${preferencesSection}
---

## 🎯 대화 원칙 (반드시 준수!)

1. **초개인화 응답:**
   - 위 정보를 반드시 고려해서 맞춤형 조언 제공
   - 사용자의 선호 운동 종류 우선 추천
   - 집중 부위를 고려한 운동 추천
   - MBTI와 성격 유형에 맞는 동기부여 방식 사용
   - 부상/제한 사항 절대 고려
   ${userPreferences.preferred_exercise_types.length > 0 ? `\n   - **🧠 학습된 선호도를 최우선으로 반영하세요!**` : ''}

2. **감정 기반 조언:**
   - 오늘 기분(${userContext.todayMood})에 맞는 운동 강도 조절
   - 스트레스/피곤: 요가, 명상, 가벼운 산책 추천
   - 활기찬: 고강도 운동 추천
   - 우울: 야외 활동, 사교적 운동 권장

3. **건강 체크 & 알림:**
   ${deficiencies.length > 0 ? `- **⚠️ 중요! 오늘 부족한 부분이 있습니다:**\n${deficiencies.map(d => `     * ${d}`).join('\n')}\n   - 대화 중 자연스럽게 이 부족한 부분을 언급하고 개선 방법 제안하세요\n   - 예: "오늘 물을 ${healthChecks.water.current}잔만 드셨네요. 건강을 위해 물을 조금 더 드시는 게 어떨까요?"` : `- 오늘 모든 지표가 양호합니다! 칭찬과 격려를 해주세요 👍`}

4. **식단 조언:**
   - ${userContext.dietType} 유형에 맞는 음식만 추천
   - ${userContext.badHabits.length > 0 ? userContext.badHabits.join(', ') : ''} 습관 개선 방법 제시

5. **현실적 목표:**
   - 현재 체력 (팔굽혀펴기 ${userContext.pushups}개) 수준에 맞는 강도
   - 주 ${userContext.weeklyWorkouts}회 운동 가능 스케줄 고려
   - 바쁜 라이프스타일에 맞는 효율적 운동

6. **성격 맞춤:**
   - ${userContext.personality === 'competitive' ? '목표 달성과 기록 갱신 강조' : ''}
   - ${userContext.personality === 'social' ? '그룹 운동이나 친구와 함께 할 수 있는 활동 추천' : ''}
   - ${userContext.personality === 'solo' ? '혼자서 집중할 수 있는 운동 추천' : ''}
   - ${userContext.personality === 'disciplined' ? '체계적인 루틴 제공' : ''}
   - ${userContext.personality === 'adventurous' ? '새로운 운동 도전 제안' : ''}

7. **말투:**
   - 친근하고 공감하는 톤
   - 한국어로 응답
   - 이모지 적절히 사용 😊
   - 구체적이고 실용적인 조언
   - 사용자 이름 대신 "당신"이나 "회원님" 사용
   - 대화 3-4턴마다 부족한 부분을 자연스럽게 언급하기

---

## ⚠️ 중요 제약사항:
- 부상 부위: ${userContext.injuries !== '없음' && userContext.injuries !== '' ? `"${userContext.injuries}"를 고려해서 안전한 운동만 추천` : '없음'}
- 절대 의학적 진단이나 처방은 하지 말 것
- 심각한 건강 문제는 전문의 상담 권장

이제 사용자의 질문에 위 정보를 최대한 활용해서 초개인화된 답변을 해주세요!`;

    // OpenAI API 호출
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'gpt-4o-mini',
        messages: [
          { role: 'system', content: systemPrompt },
          ...(history || []),
          { role: 'user', content: message },
        ],
        temperature: 0.7,
        max_tokens: 1000,
      }),
    });

    if (!response.ok) {
      const errorData = await response.json();
      console.log('OpenAI API 에러:', errorData);
      return c.json({ error: errorData.error?.message || 'OpenAI API 호출 실패' }, 500);
    }

    const data = await response.json();
    const aiContent = data.choices[0]?.message?.content || '죄송해요, 응답을 생성할 수 없었습니다.';

    console.log('✅ OpenAI 챗 응답 성공:', user.email);

    return c.json({ 
      content: aiContent,
      message: '응답 생성 완료' 
    });
  } catch (error) {
    console.log('OpenAI 챗 처리 중 에러:', error);
    return c.json({ error: error instanceof Error ? error.message : 'Unknown error' }, 500);
  }
});

// 👍👎 피드백 저장 API
app.post('/make-server-3f0775df/feedback', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    if (!accessToken) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const supabase = getSupabaseClient();
    const { data: { user }, error: userError } = await supabase.auth.getUser(accessToken);

    if (userError || !user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const { message_id, feedback, ai_response, user_question } = await c.req.json();

    if (!message_id || !feedback) {
      return c.json({ error: 'Message ID and feedback are required' }, 400);
    }

    // 피드백 데이터 저장
    const feedbackData = {
      user_id: user.id,
      message_id,
      feedback, // "positive" or "negative"
      ai_response,
      user_question,
      timestamp: new Date().toISOString(),
    };

    // KV Store에 저장
    await kv.set(`feedback:${user.id}:${message_id}`, feedbackData);

    // 피드백 카운트 업데이트 (전체 피드백 목록 관리)
    const feedbackListKey = `feedback_list:${user.id}`;
    const existingFeedbacks = await kv.get(feedbackListKey) || [];
    existingFeedbacks.push(feedbackData);
    await kv.set(feedbackListKey, existingFeedbacks);

    // 🧠 선호도 학습 로직 실행
    await updateUserPreferences(user.id, feedback, ai_response, user_question);

    console.log('✅ 피드백 저장 성공:', user.email, feedback);

    return c.json({ 
      success: true,
      message: '피드백이 저장되었습니다!' 
    });
  } catch (error) {
    console.log('피드백 저장 중 에러:', error);
    return c.json({ error: error instanceof Error ? error.message : 'Unknown error' }, 500);
  }
});

// 📊 대화 통계 조회 API
app.get('/make-server-3f0775df/chat-stats', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    if (!accessToken) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const supabase = getSupabaseClient();
    const { data: { user }, error: userError } = await supabase.auth.getUser(accessToken);

    if (userError || !user) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    // 피드백 목록 조회
    const feedbackList = await kv.get(`feedback_list:${user.id}`) || [];

    // 통계 계산
    const totalConversations = feedbackList.length;
    const positiveCount = feedbackList.filter((f: any) => f.feedback === 'positive').length;
    const satisfactionRate = totalConversations > 0 
      ? Math.round((positiveCount / totalConversations) * 100) 
      : 0;

    return c.json({ 
      totalConversations,
      positiveCount,
      negativeCount: totalConversations - positiveCount,
      satisfactionRate,
    });
  } catch (error) {
    console.log('대화 통계 조회 중 에러:', error);
    return c.json({ error: error instanceof Error ? error.message : 'Unknown error' }, 500);
  }
});

// 🧠 선호도 학습 헬퍼 함수
async function updateUserPreferences(userId: string, feedback: string, aiResponse: string, userQuestion: string) {
  try {
    // 기존 선호도 데이터 조회
    const preferences = await kv.get(`user_preferences:${userId}`) || {
      preferred_topics: [],
      preferred_exercise_types: [],
      disliked_exercise_types: [],
      preferred_response_style: null,
    };

    // 🔍 키워드 추출 (간단한 패턴 매칭)
    const exerciseKeywords = [
      '요가', '명상', '걷기', '러닝', '조깅', '수영', '필라테스', 
      '스트레칭', '사이클', 'HIIT', '웨이트', '근력', '유산소',
      '맨몸운동', '헬스', '홈트', '계단', '등산'
    ];

    const topicKeywords = {
      '운동': ['운동', '트레이닝', '루틴', '체력'],
      '식단': ['식단', '음식', '영양', '칼로리', '다이어트'],
      '수면': ['수면', '잠', '수면시간', '불면증'],
      '스트레스': ['스트레스', '긴장', '불안', '힐링'],
    };

    if (feedback === 'positive') {
      // ✅ 긍정 피드백 - 선호도 추가
      
      // 운동 종류 추출
      for (const keyword of exerciseKeywords) {
        if (aiResponse.includes(keyword) || userQuestion.includes(keyword)) {
          if (!preferences.preferred_exercise_types.includes(keyword)) {
            preferences.preferred_exercise_types.push(keyword);
          }
          // 비선호에서 제거
          preferences.disliked_exercise_types = preferences.disliked_exercise_types.filter(
            (e: string) => e !== keyword
          );
        }
      }

      // 주제 추출
      for (const [topic, keywords] of Object.entries(topicKeywords)) {
        for (const keyword of keywords) {
          if (aiResponse.includes(keyword) || userQuestion.includes(keyword)) {
            if (!preferences.preferred_topics.includes(topic)) {
              preferences.preferred_topics.push(topic);
            }
            break;
          }
        }
      }

    } else if (feedback === 'negative') {
      // ❌ 부정 피드백 - 비선호 추가
      
      // 운동 종류 추출
      for (const keyword of exerciseKeywords) {
        if (aiResponse.includes(keyword) || userQuestion.includes(keyword)) {
          if (!preferences.disliked_exercise_types.includes(keyword)) {
            preferences.disliked_exercise_types.push(keyword);
          }
          // 선호에서 제거
          preferences.preferred_exercise_types = preferences.preferred_exercise_types.filter(
            (e: string) => e !== keyword
          );
        }
      }
    }

    // 선호도 데이터 저장
    await kv.set(`user_preferences:${userId}`, preferences);

    console.log('🧠 선호도 업데이트 완료:', userId, preferences);

  } catch (error) {
    console.log('선호도 업데이트 에러:', error);
  }
}

// Health check
app.get('/make-server-3f0775df/health', (c) => {
  return c.json({ status: 'ok', message: 'HealCat Server is running!' });
});

Deno.serve(app.fetch);