// 데이터베이스 초기 설정 스크립트
import { createClient } from 'npm:@supabase/supabase-js@2';

export async function setupDatabase() {
  const supabase = createClient(
    Deno.env.get('SUPABASE_URL') ?? '',
    Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
  );

  console.log('🔧 데이터베이스 초기화 시작...');

  try {
    // 1. user_profiles 테이블 생성
    await supabase.rpc('exec_sql', {
      sql: `
        CREATE TABLE IF NOT EXISTS user_profiles (
          id UUID REFERENCES auth.users PRIMARY KEY,
          email TEXT NOT NULL,
          
          -- Physical Profile
          height INTEGER,
          weight INTEGER,
          bmi DECIMAL(4,1),
          goal TEXT CHECK (goal IN ('lose', 'maintain', 'gain', 'wellness')),
          
          -- Emotional & Energy State
          current_mood TEXT CHECK (current_mood IN ('energetic', 'balanced', 'tired', 'stressed')),
          energy_pattern TEXT CHECK (energy_pattern IN ('morning', 'night', 'varies')),
          stress_level TEXT CHECK (stress_level IN ('low', 'moderate', 'high')),
          
          -- Lifestyle & Preferences
          activity_level TEXT CHECK (activity_level IN ('sedentary', 'lightly_active', 'moderately_active', 'very_active')),
          preferred_workout_time TEXT CHECK (preferred_workout_time IN ('morning', 'afternoon', 'evening', 'flexible')),
          workout_environment TEXT CHECK (workout_environment IN ('home', 'gym', 'outdoor', 'any')),
          
          -- Motivations & Challenges
          primary_motivation TEXT CHECK (primary_motivation IN ('health', 'appearance', 'energy', 'stress_relief', 'sleep_quality')),
          biggest_challenge TEXT CHECK (biggest_challenge IN ('time', 'motivation', 'energy', 'knowledge', 'consistency')),
          dietary_preference TEXT CHECK (dietary_preference IN ('none', 'vegetarian', 'vegan', 'low_carb', 'other')),
          
          -- Gamification
          level INTEGER DEFAULT 1,
          xp INTEGER DEFAULT 0,
          total_points INTEGER DEFAULT 0,
          streak INTEGER DEFAULT 0,
          
          -- Timestamps
          created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc', NOW()),
          updated_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc', NOW())
        );
      `
    }).catch(() => {
      // RPC가 없으면 직접 쿼리 시도
      console.log('RPC 방식 실패, 직접 테이블 확인...');
    });

    // 2. daily_activities 테이블 생성
    await supabase.rpc('exec_sql', {
      sql: `
        CREATE TABLE IF NOT EXISTS daily_activities (
          id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
          user_id UUID REFERENCES auth.users NOT NULL,
          date DATE NOT NULL,
          
          -- Physical Metrics
          water_glasses INTEGER DEFAULT 0,
          sleep_hours DECIMAL(3,1) DEFAULT 0,
          sleep_quality INTEGER DEFAULT 0,
          meals_completed INTEGER DEFAULT 0,
          steps INTEGER DEFAULT 0,
          calories_intake INTEGER DEFAULT 0,
          calories_burned INTEGER DEFAULT 0,
          
          -- Emotional & Situational Context
          morning_mood TEXT CHECK (morning_mood IN ('energetic', 'balanced', 'tired', 'stressed')),
          evening_mood TEXT CHECK (evening_mood IN ('energetic', 'balanced', 'tired', 'stressed')),
          stress_level TEXT CHECK (stress_level IN ('low', 'moderate', 'high')),
          energy_level INTEGER CHECK (energy_level BETWEEN 1 AND 10),
          
          -- Workout Adaptation
          workout_completed BOOLEAN DEFAULT false,
          workout_type TEXT,
          workout_adjusted BOOLEAN DEFAULT false,
          workout_intensity TEXT CHECK (workout_intensity IN ('light', 'moderate', 'high')),
          
          -- Notes
          daily_note TEXT,
          
          created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc', NOW()),
          UNIQUE(user_id, date)
        );
      `
    }).catch(() => console.log('daily_activities 확인...'));

    // 3. badges 테이블 생성
    await supabase.rpc('exec_sql', {
      sql: `
        CREATE TABLE IF NOT EXISTS badges (
          id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
          name TEXT NOT NULL,
          description TEXT,
          icon TEXT,
          condition TEXT,
          created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc', NOW())
        );
      `
    }).catch(() => console.log('badges 확인...'));

    // 4. user_badges 테이블 생성
    await supabase.rpc('exec_sql', {
      sql: `
        CREATE TABLE IF NOT EXISTS user_badges (
          id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
          user_id UUID REFERENCES auth.users NOT NULL,
          badge_id UUID REFERENCES badges NOT NULL,
          unlocked_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc', NOW()),
          UNIQUE(user_id, badge_id)
        );
      `
    }).catch(() => console.log('user_badges 확인...'));

    // 5. challenges 테이블 생성
    await supabase.rpc('exec_sql', {
      sql: `
        CREATE TABLE IF NOT EXISTS challenges (
          id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
          title TEXT NOT NULL,
          description TEXT,
          total INTEGER NOT NULL,
          points INTEGER DEFAULT 0,
          deadline_days INTEGER,
          challenge_type TEXT CHECK (challenge_type IN ('weekly', 'daily', 'monthly')),
          created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc', NOW())
        );
      `
    }).catch(() => console.log('challenges 확인...'));

    // 6. user_challenges 테이블 생성
    await supabase.rpc('exec_sql', {
      sql: `
        CREATE TABLE IF NOT EXISTS user_challenges (
          id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
          user_id UUID REFERENCES auth.users NOT NULL,
          challenge_id UUID REFERENCES challenges NOT NULL,
          progress INTEGER DEFAULT 0,
          completed BOOLEAN DEFAULT false,
          started_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc', NOW()),
          completed_at TIMESTAMP WITH TIME ZONE,
          UNIQUE(user_id, challenge_id)
        );
      `
    }).catch(() => console.log('user_challenges 확인...'));

    console.log('✅ 데이터베이스 초기화 완료!');

    // 초기 배지 데이터 삽입
    await insertInitialBadges(supabase);

  } catch (error) {
    console.log('⚠️ 데이터베이스 초기화 중 에러 (테이블이 이미 존재할 수 있음):', error);
  }
}

async function insertInitialBadges(supabase: any) {
  try {
    // 배지가 이미 있는지 확인
    const { data: existingBadges } = await supabase
      .from('badges')
      .select('id')
      .limit(1);

    if (existingBadges && existingBadges.length > 0) {
      console.log('✅ 배지 데이터가 이미 존재합니다.');
      return;
    }

    // 초기 배지 데이터
    const badges = [
      {
        name: '첫 걸음',
        description: '첫 번째 운동 완료',
        icon: '🎯',
        condition: 'Complete first workout',
      },
      {
        name: '일주일 챌린저',
        description: '7일 연속 활동 기록',
        icon: '🔥',
        condition: '7 day streak',
      },
      {
        name: '수분 마스터',
        description: '하루 물 8잔 달성',
        icon: '💧',
        condition: 'Drink 8 glasses of water',
      },
      {
        name: '얼리버드',
        description: '아침 운동 10회 완료',
        icon: '🌅',
        condition: '10 morning workouts',
      },
      {
        name: '철인',
        description: '30일 연속 운동',
        icon: '💪',
        condition: '30 day workout streak',
      },
      {
        name: '건강 달인',
        description: '100회 운동 완료',
        icon: '👑',
        condition: 'Complete 100 workouts',
      },
    ];

    const { error } = await supabase.from('badges').insert(badges);

    if (error) {
      console.log('배지 삽입 에러:', error);
    } else {
      console.log('✅ 초기 배지 데이터 삽입 완료!');
    }
  } catch (error) {
    console.log('배지 삽입 중 에러:', error);
  }
}
