import { Card } from "./ui/card";
import { Badge } from "./ui/badge";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { Flame, Footprints, Target } from "lucide-react";

interface ActivityCardProps {
  title: string;
  calories: number;
  duration: number;
  steps?: number;
  completed: boolean;
}

function ActivityCard({ title, calories, duration, steps, completed }: ActivityCardProps) {
  return (
    <div className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50 transition-colors">
      <div className="flex items-center gap-4">
        <div className={`w-2 h-12 rounded-full ${completed ? 'bg-green-500' : 'bg-gray-300'}`} />
        <div>
          <h4 className="mb-1">{title}</h4>
          <div className="flex gap-3 text-sm text-gray-500">
            <span className="flex items-center gap-1">
              <Flame className="w-4 h-4" />
              {calories} kcal
            </span>
            <span>{duration}분</span>
            {steps && (
              <span className="flex items-center gap-1">
                <Footprints className="w-4 h-4" />
                {steps.toLocaleString()}
              </span>
            )}
          </div>
        </div>
      </div>
      <Badge variant={completed ? "default" : "secondary"}>
        {completed ? "완료" : "예정"}
      </Badge>
    </div>
  );
}

export function ActivityTracker() {
  const activities = [
    { title: "아침 조깅", calories: 320, duration: 30, steps: 4200, completed: true },
    { title: "요가 세션", calories: 180, duration: 45, completed: true },
    { title: "저녁 산책", calories: 150, duration: 25, steps: 3000, completed: false },
    { title: "근력 운동", calories: 280, duration: 40, completed: false }
  ];

  const dailyGoal = {
    current: 500,
    target: 800,
    steps: 7200,
    targetSteps: 10000
  };

  return (
    <Card className="p-6">
      <div className="flex items-center justify-between mb-6">
        <h3>오늘의 활동</h3>
        <Target className="w-5 h-5 text-gray-400" />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
        <div className="p-4 bg-gradient-to-br from-orange-50 to-orange-100 rounded-lg">
          <p className="text-sm text-gray-600 mb-1">칼로리 소모</p>
          <p className="text-2xl mb-2">{dailyGoal.current} / {dailyGoal.target} kcal</p>
          <div className="w-full bg-white rounded-full h-2">
            <div 
              className="bg-orange-500 h-2 rounded-full transition-all"
              style={{ width: `${(dailyGoal.current / dailyGoal.target) * 100}%` }}
            />
          </div>
        </div>

        <div className="p-4 bg-gradient-to-br from-blue-50 to-blue-100 rounded-lg">
          <p className="text-sm text-gray-600 mb-1">걸음 수</p>
          <p className="text-2xl mb-2">{dailyGoal.steps.toLocaleString()} / {dailyGoal.targetSteps.toLocaleString()}</p>
          <div className="w-full bg-white rounded-full h-2">
            <div 
              className="bg-blue-500 h-2 rounded-full transition-all"
              style={{ width: `${(dailyGoal.steps / dailyGoal.targetSteps) * 100}%` }}
            />
          </div>
        </div>
      </div>

      <div className="space-y-3">
        {activities.map((activity, index) => (
          <ActivityCard key={index} {...activity} />
        ))}
      </div>
    </Card>
  );
}
