import { useState, useRef, useEffect } from "react";
import { Card } from "./ui/card";
import { Button } from "./ui/button";
import { Textarea } from "./ui/textarea";
import { ScrollArea } from "./ui/scroll-area";
import { Avatar } from "./ui/avatar";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { Send, Loader2, Sparkles, ThumbsUp, ThumbsDown } from "lucide-react";
import { projectId, publicAnonKey } from "../utils/supabase/info";
import { toast } from "sonner@2.0.3";

interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: Date;
  feedback?: "positive" | "negative" | null;
}

interface ChatInterfaceProps {
  accessToken?: string;
  onFeedbackSubmitted?: () => void;
  userId?: string;
}

export function ChatInterface({ accessToken, onFeedbackSubmitted, userId }: ChatInterfaceProps) {
  const catCharacterUrl = "https://images.unsplash.com/photo-1739513261094-ba34a1c9e307?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjdXRlJTIwY2F0JTIwY2FydG9vbiUyMGNoYXJhY3RlciUyMGlsbHVzdHJhdGlvbnxlbnwxfHx8fDE3NjIxODA4Njh8MA&ixlib=rb-4.1.0&q=80&w=1080";
  
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      role: "assistant",
      content: "안녕하세요! 저는 HealCat AI 건강 어시스턴트입니다 🐱 오늘 기분은 어떠세요? 건강에 대해 어떤 것이 궁금하신가요?",
      timestamp: new Date(),
      feedback: null
    }
  ]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // localStorage에서 대화 기록 불러오기
  useEffect(() => {
    if (userId) {
      const storageKey = `healcat_chat_${userId}`;
      const savedMessages = localStorage.getItem(storageKey);
      
      if (savedMessages) {
        try {
          const parsed = JSON.parse(savedMessages);
          // timestamp를 Date 객체로 변환
          const messagesWithDates = parsed.map((msg: any) => ({
            ...msg,
            timestamp: new Date(msg.timestamp)
          }));
          setMessages(messagesWithDates);
        } catch (error) {
          console.error('대화 기록 로드 실패:', error);
        }
      }
    }
  }, [userId]);

  // 대화 기록이 변경될 때마다 localStorage에 저장
  useEffect(() => {
    if (userId && messages.length > 1) { // 초기 메시지만 있는 경우 제외
      const storageKey = `healcat_chat_${userId}`;
      localStorage.setItem(storageKey, JSON.stringify(messages));
    }
  }, [messages, userId]);

  // 새 메시지가 추가되면 자동으로 스크롤
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isLoading]);

  // 피드백 제출 함수
  const handleFeedback = async (messageId: string, feedback: "positive" | "negative", messageContent: string, userQuestion: string) => {
    try {
      const token = accessToken || publicAnonKey;
      
      // 서버에 피드백 저장
      const url = `https://${projectId}.supabase.co/functions/v1/make-server-3f0775df/feedback`;
      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          message_id: messageId,
          feedback: feedback,
          ai_response: messageContent,
          user_question: userQuestion,
        }),
      });

      if (!response.ok) {
        throw new Error('피드백 저장 실패');
      }

      // 로컬 상태 업데이트
      setMessages(prev => prev.map(msg => 
        msg.id === messageId ? { ...msg, feedback } : msg
      ));

      toast.success(feedback === "positive" ? "피드백 감사합니다! 👍" : "의견 감사합니다. 더 나아지겠습니다! 👎");
      
      // 부모 컴포넌트에 피드백 제출 알림 (통계 업데이트 위해)
      if (onFeedbackSubmitted) {
        onFeedbackSubmitted();
      }
    } catch (error) {
      console.error('피드백 제출 에러:', error);
      toast.error('피드백 저장에 실패했습니다.');
    }
  };

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: "user",
      content: input,
      timestamp: new Date(),
      feedback: null
    };

    setMessages(prev => [...prev, userMessage]);
    const userInput = input;
    setInput("");
    setIsLoading(true);

    try {
      // Supabase Edge Function을 통해 OpenAI 호출
      const token = accessToken || publicAnonKey;
      
      console.log('🔑 사용 중인 토큰:', token ? '있음' : '없음');
      console.log('📡 API 호출 시작...');
      
      // 대화 히스토리 구성 (최근 10개 메시지만)
      const conversationHistory = messages
        .slice(-10)
        .map(msg => ({
          role: msg.role === "user" ? "user" : "assistant",
          content: msg.content
        }));

      const url = `https://${projectId}.supabase.co/functions/v1/make-server-3f0775df/chat`;
      console.log('📍 요청 URL:', url);

      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          message: userInput,
          history: conversationHistory,
        }),
      });

      console.log('📥 응답 상태:', response.status, response.statusText);

      if (!response.ok) {
        const errorData = await response.json();
        console.error('❌ 서버 에러:', errorData);
        throw new Error(errorData.error || "서버 응답 오류");
      }

      const data = await response.json();
      console.log('✅ 응답 데이터:', data);
      
      const aiContent = data.content || "죄송해요, 응답을 생성할 수 없었습니다.";

      const aiResponse: Message = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: aiContent,
        timestamp: new Date(),
        feedback: null
      };

      setMessages(prev => [...prev, aiResponse]);
    } catch (error) {
      console.error("❌ OpenAI API 에러:", error);
      
      // 에러 메시지 표시
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: `죄송해요, 문제가 발생했습니다. 😔\n\n${error instanceof Error ? error.message : "알 수 없는 오류가 발생했습니다."}\n\n잠시 후 다시 시도해주세요.`,
        timestamp: new Date(),
        feedback: null
      };
      
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const quickQuestions = [
    "오늘 스트레스 받아서 운동이 힘들어요",
    "피곤한데 에너지 높일 방법은?",
    "기분 좋은 날, 집중 운동 추천해줘",
    "바쁜 날 10분 운동 추천",
    "잠을 못 자서 피곤해요",
    "집에서 간단한 운동 알려줘",
    "회의 전 빠른 스트레스 해소법",
    "초보자 운동 루틴 추천해줘"
  ];

  return (
    <Card className="flex flex-col h-[600px] border-blue-100 shadow-md overflow-hidden">
      {/* Header - 고정 */}
      <div className="flex-shrink-0 p-4 border-b border-blue-100 bg-gradient-to-r from-blue-50 to-sky-50">
        <div className="flex items-center gap-3">
          <div className="relative">
            <Avatar className="w-11 h-11 border-2 border-white shadow-sm">
              <ImageWithFallback
                src={catCharacterUrl}
                alt="HealCat"
                className="w-full h-full object-cover"
              />
            </Avatar>
            <Sparkles className="w-4 h-4 text-blue-500 absolute -top-1 -right-1 animate-pulse" />
          </div>
          <div>
            <h3 className="flex items-center gap-2 text-gray-800">
              HealCat AI 어시스턴트
            </h3>
            <p className="text-sm text-blue-600">24/7 건강 상담 가능 💙</p>
          </div>
        </div>
      </div>

      {/* Messages Area - 스크롤 가능 */}
      <div className="flex-1 overflow-hidden">
        <ScrollArea className="h-full">
          <div className="p-4 space-y-4">
            {messages.map((message, index) => (
              <div
                key={message.id}
                className={`flex gap-3 items-start ${message.role === "user" ? "flex-row-reverse" : ""}`}
              >
                {message.role === "assistant" && (
                  <Avatar className="w-8 h-8 flex-shrink-0 shadow-sm">
                    <ImageWithFallback
                      src={catCharacterUrl}
                      alt="HealCat"
                      className="w-full h-full object-cover"
                    />
                  </Avatar>
                )}
                <div className="flex flex-col gap-2 max-w-[85%]">
                  <div
                    className={`rounded-2xl px-4 py-3 break-words ${
                      message.role === "user"
                        ? "bg-gradient-to-r from-blue-500 to-blue-600 text-white shadow-sm"
                        : "bg-blue-50 text-gray-900 border border-blue-100"
                    }`}
                  >
                    <p className="text-sm leading-relaxed whitespace-pre-wrap">{message.content}</p>
                  </div>
                  
                  {/* 피드백 버튼 - AI 메시지에만 표시 (첫 인사 메시지 제외) */}
                  {message.role === "assistant" && index > 0 && (
                    <div className="flex gap-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        className={`h-7 px-2 text-xs ${
                          message.feedback === "positive" 
                            ? "bg-green-100 text-green-700 hover:bg-green-100" 
                            : "text-gray-500 hover:bg-blue-50"
                        }`}
                        onClick={() => {
                          const userQuestion = messages[index - 1]?.content || "";
                          handleFeedback(message.id, "positive", message.content, userQuestion);
                        }}
                        disabled={message.feedback !== null}
                      >
                        <ThumbsUp className="w-3 h-3 mr-1" />
                        도움됨
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        className={`h-7 px-2 text-xs ${
                          message.feedback === "negative" 
                            ? "bg-red-100 text-red-700 hover:bg-red-100" 
                            : "text-gray-500 hover:bg-blue-50"
                        }`}
                        onClick={() => {
                          const userQuestion = messages[index - 1]?.content || "";
                          handleFeedback(message.id, "negative", message.content, userQuestion);
                        }}
                        disabled={message.feedback !== null}
                      >
                        <ThumbsDown className="w-3 h-3 mr-1" />
                        아쉬워요
                      </Button>
                    </div>
                  )}
                </div>
              </div>
            ))}
            {isLoading && (
              <div className="flex gap-3 items-start">
                <Avatar className="w-8 h-8 flex-shrink-0 shadow-sm">
                  <ImageWithFallback
                    src={catCharacterUrl}
                    alt="HealCat"
                    className="w-full h-full object-cover"
                  />
                </Avatar>
                <div className="bg-blue-50 rounded-2xl px-4 py-3 border border-blue-100">
                  <Loader2 className="w-5 h-5 animate-spin text-blue-500" />
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>
        </ScrollArea>
      </div>

      {/* Quick Questions - 첫 메시지일 때만 표시 */}
      {messages.length === 1 && (
        <div className="flex-shrink-0 px-4 py-3 border-t border-blue-100 bg-white/50">
          <p className="text-xs text-blue-600 mb-2">💬 감정과 상황에 맞는 빠른 질문:</p>
          <div className="grid grid-cols-2 gap-2 max-h-[120px] overflow-y-auto">
            {quickQuestions.map((question, index) => (
              <Button
                key={index}
                variant="outline"
                size="sm"
                className="text-xs h-auto py-2 whitespace-normal text-left justify-start border-blue-200 hover:bg-blue-50 hover:border-blue-300 bg-white"
                onClick={() => setInput(question)}
              >
                {question}
              </Button>
            ))}
          </div>
        </div>
      )}

      {/* Input Area - 고정 */}
      <div className="flex-shrink-0 p-4 border-t border-blue-100 bg-gradient-to-r from-blue-50/50 to-sky-50/50">
        <div className="flex gap-2">
          <Textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                handleSend();
              }
            }}
            placeholder="건강에 대해 무엇이든 물어보세요... 😊"
            className="min-h-[60px] max-h-[120px] resize-none border-blue-200 bg-white"
            rows={2}
          />
          <Button
            onClick={handleSend}
            disabled={!input.trim() || isLoading}
            className="px-4 h-auto self-end bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white shadow-sm"
          >
            {isLoading ? (
              <Loader2 className="w-5 h-5 animate-spin" />
            ) : (
              <Send className="w-5 h-5" />
            )}
          </Button>
        </div>
      </div>
    </Card>
  );
}