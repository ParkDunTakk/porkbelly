import { Card } from "./ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { LineChart, Line, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";

export function HealthChart() {
  const weightData = [
    { date: "11/01", value: 72.5 },
    { date: "11/08", value: 72.0 },
    { date: "11/15", value: 71.8 },
    { date: "11/22", value: 71.2 },
    { date: "11/29", value: 70.8 },
    { date: "12/06", value: 70.5 },
  ];

  const activityData = [
    { day: "월", calories: 420, steps: 8200 },
    { day: "화", calories: 380, steps: 7500 },
    { day: "수", calories: 520, steps: 9800 },
    { day: "목", calories: 450, steps: 8600 },
    { day: "금", calories: 490, steps: 9200 },
    { day: "토", calories: 610, steps: 11500 },
    { day: "일", calories: 380, steps: 7200 },
  ];

  const sleepData = [
    { day: "월", hours: 7.5 },
    { day: "화", hours: 6.8 },
    { day: "수", hours: 8.2 },
    { day: "목", hours: 7.0 },
    { day: "금", hours: 6.5 },
    { day: "토", hours: 8.5 },
    { day: "일", hours: 7.5 },
  ];

  return (
    <Card className="p-6">
      <h3 className="mb-6">건강 추이</h3>
      
      <Tabs defaultValue="weight" className="w-full">
        <TabsList className="grid w-full grid-cols-3 mb-6">
          <TabsTrigger value="weight">체중</TabsTrigger>
          <TabsTrigger value="activity">활동량</TabsTrigger>
          <TabsTrigger value="sleep">수면</TabsTrigger>
        </TabsList>

        <TabsContent value="weight" className="space-y-4">
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={weightData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis dataKey="date" stroke="#888" />
                <YAxis stroke="#888" domain={[70, 73]} />
                <Tooltip />
                <Line 
                  type="monotone" 
                  dataKey="value" 
                  stroke="#8b5cf6" 
                  strokeWidth={2}
                  dot={{ fill: '#8b5cf6', r: 4 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
          <p className="text-sm text-gray-500 text-center">지난 6주간 체중 변화 (kg)</p>
        </TabsContent>

        <TabsContent value="activity" className="space-y-4">
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={activityData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis dataKey="day" stroke="#888" />
                <YAxis stroke="#888" />
                <Tooltip />
                <Area 
                  type="monotone" 
                  dataKey="calories" 
                  stroke="#f97316" 
                  fill="#fed7aa" 
                  strokeWidth={2}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
          <p className="text-sm text-gray-500 text-center">주간 칼로리 소모량 (kcal)</p>
        </TabsContent>

        <TabsContent value="sleep" className="space-y-4">
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={sleepData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis dataKey="day" stroke="#888" />
                <YAxis stroke="#888" domain={[0, 10]} />
                <Tooltip />
                <Area 
                  type="monotone" 
                  dataKey="hours" 
                  stroke="#3b82f6" 
                  fill="#bfdbfe" 
                  strokeWidth={2}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
          <p className="text-sm text-gray-500 text-center">주간 수면 시간 (시간)</p>
        </TabsContent>
      </Tabs>
    </Card>
  );
}
