import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "./ui/dialog";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { RadioGroup, RadioGroupItem } from "./ui/radio-group";
import { Slider } from "./ui/slider";
import { Progress } from "./ui/progress";
import { Checkbox } from "./ui/checkbox";
import { Textarea } from "./ui/textarea";
import { 
  User, 
  Target, 
  Heart, 
  Dumbbell, 
  Utensils,
  Brain,
  Activity,
  TrendingUp,
  Smile,
  Zap
} from "lucide-react";

interface OnboardingData {
  // Step 1: 기본 정보
  gender: string;
  height: string;
  weight: string;
  bmi?: number;
  bodyType: string;

  // Step 2: 목표 및 관심사
  goal: string;
  interests: string[];
  exerciseTypes: string[];

  // Step 3: 신체 정보
  focusAreas: string[];
  specialProgram: string;
  injuries: string;

  // Step 4: 라이프스타일
  lifestyleActivity: string;
  energyLevel: number;
  weeklyWorkouts: number;

  // Step 5: 현재 상태
  pushups: number;
  walkingTime: number;
  sleepTime: number;

  // Step 6: 식습관
  dietType: string;
  badHabits: string[];

  // Step 7: 성격
  mbti: string;
  personality: string;
}

interface OnboardingModalProps {
  open: boolean;
  onComplete: (data: OnboardingData) => void;
}

export function OnboardingModal({ open, onComplete }: OnboardingModalProps) {
  const [step, setStep] = useState(1);
  const [data, setData] = useState<OnboardingData>({
    gender: "",
    height: "",
    weight: "",
    bodyType: "",
    goal: "",
    interests: [],
    exerciseTypes: [],
    focusAreas: [],
    specialProgram: "",
    injuries: "",
    lifestyleActivity: "",
    energyLevel: 5,
    weeklyWorkouts: 3,
    pushups: 0,
    walkingTime: 30,
    sleepTime: 7,
    dietType: "",
    badHabits: [],
    mbti: "",
    personality: "",
  });

  const totalSteps = 7;
  const progress = (step / totalSteps) * 100;

  const handleNext = () => {
    if (step < totalSteps) {
      setStep(step + 1);
    } else {
      // BMI 계산
      const heightM = parseFloat(data.height) / 100;
      const weightKg = parseFloat(data.weight);
      const bmi = heightM && weightKg ? weightKg / (heightM * heightM) : 0;
      
      onComplete({ ...data, bmi });
    }
  };

  const handleBack = () => {
    if (step > 1) {
      setStep(step - 1);
    }
  };

  const toggleArrayItem = (array: string[], item: string) => {
    if (array.includes(item)) {
      return array.filter((i) => i !== item);
    } else {
      return [...array, item];
    }
  };

  const canProceed = () => {
    switch (step) {
      case 1:
        return data.gender && data.height && data.weight && data.bodyType;
      case 2:
        return data.goal && data.interests.length > 0 && data.exerciseTypes.length > 0;
      case 3:
        return data.focusAreas.length > 0;
      case 4:
        return data.lifestyleActivity && data.weeklyWorkouts > 0;
      case 5:
        return data.sleepTime > 0;
      case 6:
        return data.dietType;
      case 7:
        return data.mbti && data.personality;
      default:
        return false;
    }
  };

  const calculateBMI = () => {
    const heightM = parseFloat(data.height) / 100;
    const weightKg = parseFloat(data.weight);
    if (heightM && weightKg) {
      return (weightKg / (heightM * heightM)).toFixed(1);
    }
    return null;
  };

  const getBMICategory = (bmi: number) => {
    if (bmi < 18.5) return { text: "저체중", color: "text-blue-600" };
    if (bmi < 25) return { text: "정상", color: "text-green-600" };
    if (bmi < 30) return { text: "과체중", color: "text-yellow-600" };
    return { text: "비만", color: "text-red-600" };
  };

  return (
    <Dialog open={open}>
      <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto" hideClose>
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <span className="text-2xl">🐱</span>
            HealCat 맞춤 설정 ({step}/{totalSteps})
          </DialogTitle>
          <DialogDescription>
            당신만을 위한 완벽한 건강 계획을 만들어드릴게요
          </DialogDescription>
        </DialogHeader>

        <Progress value={progress} className="mb-4" />

        <div className="space-y-6">
          {/* Step 1: 기본 정보 */}
          {step === 1 && (
            <div className="space-y-4">
              <div className="flex items-center gap-2 mb-4">
                <User className="w-5 h-5 text-blue-600" />
                <h3 className="text-gray-900">기본 정보</h3>
              </div>

              <div>
                <Label>성별</Label>
                <RadioGroup value={data.gender} onValueChange={(value) => setData({ ...data, gender: value })}>
                  <div className="grid grid-cols-2 gap-3 mt-2">
                    <div className="flex items-center space-x-2 p-3 border rounded-lg hover:bg-blue-50 cursor-pointer">
                      <RadioGroupItem value="male" id="male" />
                      <Label htmlFor="male" className="cursor-pointer flex-1">남성</Label>
                    </div>
                    <div className="flex items-center space-x-2 p-3 border rounded-lg hover:bg-blue-50 cursor-pointer">
                      <RadioGroupItem value="female" id="female" />
                      <Label htmlFor="female" className="cursor-pointer flex-1">여성</Label>
                    </div>
                  </div>
                </RadioGroup>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="height">키 (cm)</Label>
                  <Input
                    id="height"
                    type="number"
                    placeholder="170"
                    value={data.height}
                    onChange={(e) => setData({ ...data, height: e.target.value })}
                    className="border-blue-200"
                  />
                </div>
                <div>
                  <Label htmlFor="weight">체중 (kg)</Label>
                  <Input
                    id="weight"
                    type="number"
                    placeholder="65"
                    value={data.weight}
                    onChange={(e) => setData({ ...data, weight: e.target.value })}
                    className="border-blue-200"
                  />
                </div>
              </div>

              {data.height && data.weight && calculateBMI() && (
                <div className="p-4 bg-gradient-to-r from-blue-50 to-sky-50 rounded-xl border border-blue-200">
                  <p className="text-sm text-gray-600 mb-1">당신의 BMI</p>
                  <p className="text-3xl mb-1">{calculateBMI()}</p>
                  <p className={`text-sm ${getBMICategory(parseFloat(calculateBMI()!)).color}`}>
                    {getBMICategory(parseFloat(calculateBMI()!)).text}
                  </p>
                </div>
              )}

              <div>
                <Label>내 체형</Label>
                <RadioGroup value={data.bodyType} onValueChange={(value) => setData({ ...data, bodyType: value })}>
                  <div className="grid grid-cols-2 gap-3 mt-2">
                    <div className="flex items-center space-x-2 p-3 border rounded-lg hover:bg-blue-50 cursor-pointer">
                      <RadioGroupItem value="ectomorph" id="ectomorph" />
                      <Label htmlFor="ectomorph" className="cursor-pointer flex-1">마른 체형</Label>
                    </div>
                    <div className="flex items-center space-x-2 p-3 border rounded-lg hover:bg-blue-50 cursor-pointer">
                      <RadioGroupItem value="mesomorph" id="mesomorph" />
                      <Label htmlFor="mesomorph" className="cursor-pointer flex-1">근육질 체형</Label>
                    </div>
                    <div className="flex items-center space-x-2 p-3 border rounded-lg hover:bg-blue-50 cursor-pointer">
                      <RadioGroupItem value="endomorph" id="endomorph" />
                      <Label htmlFor="endomorph" className="cursor-pointer flex-1">통통한 체형</Label>
                    </div>
                    <div className="flex items-center space-x-2 p-3 border rounded-lg hover:bg-blue-50 cursor-pointer">
                      <RadioGroupItem value="average" id="average" />
                      <Label htmlFor="average" className="cursor-pointer flex-1">보통 체형</Label>
                    </div>
                  </div>
                </RadioGroup>
              </div>
            </div>
          )}

          {/* Step 2: 목표 및 관심사 */}
          {step === 2 && (
            <div className="space-y-4">
              <div className="flex items-center gap-2 mb-4">
                <Target className="w-5 h-5 text-blue-600" />
                <h3 className="text-gray-900">목표 & 관심사</h3>
              </div>

              <div>
                <Label>주요 목표</Label>
                <RadioGroup value={data.goal} onValueChange={(value) => setData({ ...data, goal: value })}>
                  <div className="space-y-2 mt-2">
                    {[
                      { value: "weight_loss", label: "체중 감량", icon: "📉" },
                      { value: "muscle_gain", label: "근육 강화", icon: "💪" },
                      { value: "health_maintenance", label: "건강 유지", icon: "❤️" },
                      { value: "flexibility", label: "유연성 향상", icon: "🧘" },
                      { value: "endurance", label: "지구력 향상", icon: "🏃" },
                    ].map((goal) => (
                      <div key={goal.value} className="flex items-center space-x-2 p-3 border rounded-lg hover:bg-blue-50 cursor-pointer">
                        <RadioGroupItem value={goal.value} id={goal.value} />
                        <Label htmlFor={goal.value} className="cursor-pointer flex-1 flex items-center gap-2">
                          <span>{goal.icon}</span>
                          <span>{goal.label}</span>
                        </Label>
                      </div>
                    ))}
                  </div>
                </RadioGroup>
              </div>

              <div>
                <Label>관심 분야 (복수 선택 가능)</Label>
                <div className="grid grid-cols-2 gap-3 mt-2">
                  {[
                    { value: "meal_plan", label: "식단 플랜" },
                    { value: "calorie_tracking", label: "칼로리 계산" },
                    { value: "workout_plan", label: "운동 플랜" },
                    { value: "fasting", label: "간헐적 단식" },
                  ].map((interest) => (
                    <div
                      key={interest.value}
                      className={`flex items-center space-x-2 p-3 border rounded-lg cursor-pointer transition-colors ${
                        data.interests.includes(interest.value) ? "bg-blue-100 border-blue-300" : "hover:bg-blue-50"
                      }`}
                      onClick={() => setData({ ...data, interests: toggleArrayItem(data.interests, interest.value) })}
                    >
                      <Checkbox
                        checked={data.interests.includes(interest.value)}
                        onCheckedChange={() => {}}
                      />
                      <Label className="cursor-pointer flex-1">{interest.label}</Label>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <Label>관심있는 운동 (복수 ���택 가능)</Label>
                <div className="grid grid-cols-2 gap-3 mt-2">
                  {[
                    { value: "fitness", label: "피트니스" },
                    { value: "running", label: "러닝" },
                    { value: "gym", label: "헬스" },
                    { value: "yoga", label: "요가" },
                    { value: "walking", label: "걷기" },
                    { value: "swimming", label: "수영" },
                    { value: "cycling", label: "사이클" },
                    { value: "pilates", label: "필라테스" },
                  ].map((exercise) => (
                    <div
                      key={exercise.value}
                      className={`flex items-center space-x-2 p-3 border rounded-lg cursor-pointer transition-colors ${
                        data.exerciseTypes.includes(exercise.value) ? "bg-blue-100 border-blue-300" : "hover:bg-blue-50"
                      }`}
                      onClick={() => setData({ ...data, exerciseTypes: toggleArrayItem(data.exerciseTypes, exercise.value) })}
                    >
                      <Checkbox
                        checked={data.exerciseTypes.includes(exercise.value)}
                        onCheckedChange={() => {}}
                      />
                      <Label className="cursor-pointer flex-1">{exercise.label}</Label>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Step 3: 신체 정보 */}
          {step === 3 && (
            <div className="space-y-4">
              <div className="flex items-center gap-2 mb-4">
                <Dumbbell className="w-5 h-5 text-blue-600" />
                <h3 className="text-gray-900">신체 정보</h3>
              </div>

              <div>
                <Label>집중하고 싶은 부위 (복수 선택 가능)</Label>
                <div className="grid grid-cols-2 gap-3 mt-2">
                  {[
                    { value: "abs", label: "복근" },
                    { value: "arms", label: "팔" },
                    { value: "legs", label: "다리" },
                    { value: "chest", label: "가슴" },
                    { value: "back", label: "등" },
                    { value: "shoulders", label: "어깨" },
                    { value: "glutes", label: "엉덩이" },
                    { value: "full_body", label: "전신" },
                  ].map((area) => (
                    <div
                      key={area.value}
                      className={`flex items-center space-x-2 p-3 border rounded-lg cursor-pointer transition-colors ${
                        data.focusAreas.includes(area.value) ? "bg-blue-100 border-blue-300" : "hover:bg-blue-50"
                      }`}
                      onClick={() => setData({ ...data, focusAreas: toggleArrayItem(data.focusAreas, area.value) })}
                    >
                      <Checkbox
                        checked={data.focusAreas.includes(area.value)}
                        onCheckedChange={() => {}}
                      />
                      <Label className="cursor-pointer flex-1">{area.label}</Label>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <Label htmlFor="injuries">부상 부위나 제한사항 (선택사항)</Label>
                <Textarea
                  id="injuries"
                  placeholder="예: 무릎 통증, 허리 디스크 등"
                  value={data.injuries}
                  onChange={(e) => setData({ ...data, injuries: e.target.value })}
                  className="border-blue-200 mt-2"
                  rows={3}
                />
                <p className="text-xs text-gray-500 mt-1">
                  특정 운동을 피해야 하거나 주의가 필요한 부위가 있다면 알려주세요
                </p>
              </div>
            </div>
          )}

          {/* Step 4: 라이프스타일 */}
          {step === 4 && (
            <div className="space-y-4">
              <div className="flex items-center gap-2 mb-4">
                <Activity className="w-5 h-5 text-blue-600" />
                <h3 className="text-gray-900">라이프스타일</h3>
              </div>

              <div>
                <Label>일상의 운동 정도</Label>
                <RadioGroup value={data.lifestyleActivity} onValueChange={(value) => setData({ ...data, lifestyleActivity: value })}>
                  <div className="space-y-2 mt-2">
                    {[
                      { value: "sedentary", label: "주로 앉아서 생활", desc: "사무직, 거의 운동 안 함" },
                      { value: "lightly_active", label: "가벼운 활동", desc: "가끔 걷기, 가벼운 운동" },
                      { value: "moderately_active", label: "보통 활동", desc: "주 3-4회 운동" },
                      { value: "very_active", label: "매우 활동적", desc: "주 5-7회 운동" },
                      { value: "extremely_active", label: "극도로 활동적", desc: "매일 고강도 운동" },
                    ].map((activity) => (
                      <div key={activity.value} className="flex items-center space-x-2 p-3 border rounded-lg hover:bg-blue-50 cursor-pointer">
                        <RadioGroupItem value={activity.value} id={activity.value} />
                        <Label htmlFor={activity.value} className="cursor-pointer flex-1">
                          <p>{activity.label}</p>
                          <p className="text-sm text-gray-500">{activity.desc}</p>
                        </Label>
                      </div>
                    ))}
                  </div>
                </RadioGroup>
              </div>

              <div>
                <Label className="mb-3 block">나의 에너지 레벨 (현재)</Label>
                <div className="flex items-center gap-4">
                  <Zap className="w-5 h-5 text-yellow-500" />
                  <div className="flex-1">
                    <Slider
                      value={[data.energyLevel]}
                      onValueChange={(value) => setData({ ...data, energyLevel: value[0] })}
                      max={10}
                      min={1}
                      step={1}
                      className="w-full"
                    />
                    <div className="flex justify-between text-xs text-gray-500 mt-2">
                      <span>낮음 (1)</span>
                      <span className="text-blue-600">{data.energyLevel}</span>
                      <span>높음 (10)</span>
                    </div>
                  </div>
                </div>
              </div>

              <div>
                <Label className="mb-3 block">일주일에 운동 가능한 횟수</Label>
                <div className="flex items-center gap-4">
                  <div className="flex-1">
                    <Slider
                      value={[data.weeklyWorkouts]}
                      onValueChange={(value) => setData({ ...data, weeklyWorkouts: value[0] })}
                      max={7}
                      min={0}
                      step={1}
                      className="w-full"
                    />
                    <div className="flex justify-between text-xs text-gray-500 mt-2">
                      <span>0일</span>
                      <span className="text-blue-600">{data.weeklyWorkouts}일</span>
                      <span>7일</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Step 5: 현재 상태 */}
          {step === 5 && (
            <div className="space-y-4">
              <div className="flex items-center gap-2 mb-4">
                <TrendingUp className="w-5 h-5 text-blue-600" />
                <h3 className="text-gray-900">현재 상태</h3>
              </div>

              <div>
                <Label className="mb-3 block">한 번에 할 수 있는 팔굽혀펴기 횟수</Label>
                <div className="flex items-center gap-4">
                  <div className="flex-1">
                    <Slider
                      value={[data.pushups]}
                      onValueChange={(value) => setData({ ...data, pushups: value[0] })}
                      max={50}
                      min={0}
                      step={1}
                      className="w-full"
                    />
                    <div className="flex justify-between text-xs text-gray-500 mt-2">
                      <span>0개</span>
                      <span className="text-blue-600">{data.pushups}개</span>
                      <span>50개+</span>
                    </div>
                  </div>
                </div>
              </div>

              <div>
                <Label className="mb-3 block">매일 걷는 시간 (분)</Label>
                <div className="flex items-center gap-4">
                  <div className="flex-1">
                    <Slider
                      value={[data.walkingTime]}
                      onValueChange={(value) => setData({ ...data, walkingTime: value[0] })}
                      max={120}
                      min={0}
                      step={5}
                      className="w-full"
                    />
                    <div className="flex justify-between text-xs text-gray-500 mt-2">
                      <span>0분</span>
                      <span className="text-blue-600">{data.walkingTime}분</span>
                      <span>2시간+</span>
                    </div>
                  </div>
                </div>
              </div>

              <div>
                <Label className="mb-3 block">평균 수면 시간 (시간)</Label>
                <div className="flex items-center gap-4">
                  <div className="flex-1">
                    <Slider
                      value={[data.sleepTime]}
                      onValueChange={(value) => setData({ ...data, sleepTime: value[0] })}
                      max={12}
                      min={3}
                      step={0.5}
                      className="w-full"
                    />
                    <div className="flex justify-between text-xs text-gray-500 mt-2">
                      <span>3시간</span>
                      <span className="text-blue-600">{data.sleepTime}시간</span>
                      <span>12시간</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                <Smile className="w-5 h-5 text-blue-600 mb-2" />
                <p className="text-sm text-gray-700">
                  이 정보들은 당신의 현재 체력 수준을 파악하고 적절한 운동 강도를 추천하는데 도움이 됩니다!
                </p>
              </div>
            </div>
          )}

          {/* Step 6: 식습관 */}
          {step === 6 && (
            <div className="space-y-4">
              <div className="flex items-center gap-2 mb-4">
                <Utensils className="w-5 h-5 text-blue-600" />
                <h3 className="text-gray-900">식습관</h3>
              </div>

              <div>
                <Label>선호하는 다이어트 유형</Label>
                <RadioGroup value={data.dietType} onValueChange={(value) => setData({ ...data, dietType: value })}>
                  <div className="space-y-2 mt-2">
                    {[
                      { value: "balanced", label: "균형잡힌 식단", desc: "모든 영양소 골고루" },
                      { value: "vegetarian", label: "채식", desc: "고기 제외" },
                      { value: "vegan", label: "비건", desc: "동물성 식품 제외" },
                      { value: "keto", label: "키토", desc: "저탄수 고지방" },
                      { value: "low_carb", label: "저탄수화물", desc: "탄수화물 제한" },
                      { value: "high_protein", label: "고단백", desc: "단백질 위주" },
                      { value: "mediterranean", label: "지중해식", desc: "채소, 생선, 올리브유" },
                      { value: "flexible", label: "제한 없음", desc: "모든 음식 OK" },
                    ].map((diet) => (
                      <div key={diet.value} className="flex items-center space-x-2 p-3 border rounded-lg hover:bg-blue-50 cursor-pointer">
                        <RadioGroupItem value={diet.value} id={diet.value} />
                        <Label htmlFor={diet.value} className="cursor-pointer flex-1">
                          <p>{diet.label}</p>
                          <p className="text-sm text-gray-500">{diet.desc}</p>
                        </Label>
                      </div>
                    ))}
                  </div>
                </RadioGroup>
              </div>

              <div>
                <Label>건강하지 못했던 습관 (복수 선택 가능)</Label>
                <div className="grid grid-cols-2 gap-3 mt-2">
                  {[
                    { value: "lack_sleep", label: "휴식 부족" },
                    { value: "sugar", label: "단 것 좋아함" },
                    { value: "soda", label: "탄산음료" },
                    { value: "late_snack", label: "야식" },
                    { value: "irregular_meals", label: "불규칙한 식사" },
                    { value: "fast_food", label: "패스트푸드" },
                    { value: "alcohol", label: "음주" },
                    { value: "smoking", label: "흡연" },
                    { value: "stress_eating", label: "스트레스 폭식" },
                    { value: "skip_breakfast", label: "아침 거르기" },
                  ].map((habit) => (
                    <div
                      key={habit.value}
                      className={`flex items-center space-x-2 p-3 border rounded-lg cursor-pointer transition-colors ${
                        data.badHabits.includes(habit.value) ? "bg-red-50 border-red-300" : "hover:bg-blue-50"
                      }`}
                      onClick={() => setData({ ...data, badHabits: toggleArrayItem(data.badHabits, habit.value) })}
                    >
                      <Checkbox
                        checked={data.badHabits.includes(habit.value)}
                        onCheckedChange={() => {}}
                      />
                      <Label className="cursor-pointer flex-1">{habit.label}</Label>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Step 7: 성격 */}
          {step === 7 && (
            <div className="space-y-4">
              <div className="flex items-center gap-2 mb-4">
                <Brain className="w-5 h-5 text-blue-600" />
                <h3 className="text-gray-900">성격 유형</h3>
              </div>

              <div>
                <Label htmlFor="mbti">MBTI (선택사항)</Label>
                <Input
                  id="mbti"
                  placeholder="예: ENFP, ISTJ 등"
                  value={data.mbti}
                  onChange={(e) => setData({ ...data, mbti: e.target.value.toUpperCase() })}
                  className="border-blue-200 mt-2"
                  maxLength={4}
                />
                <p className="text-xs text-gray-500 mt-1">
                  잘 모르신다면 'XXXX' 로 입력해주세요
                </p>
              </div>

              <div>
                <Label>운동할 때 나의 성격은?</Label>
                <RadioGroup value={data.personality} onValueChange={(value) => setData({ ...data, personality: value })}>
                  <div className="space-y-2 mt-2">
                    {[
                      { value: "competitive", label: "경쟁심 강함", desc: "목표 달성과 기록 갱신에 집중" },
                      { value: "social", label: "사교적", desc: "친구들과 함께 운동하는 것을 선호" },
                      { value: "solo", label: "혼자 집중", desc: "나만의 시간과 속도로 운동" },
                      { value: "flexible", label: "유연한", desc: "상황에 따라 적응하며 운동" },
                      { value: "disciplined", label: "규칙적", desc: "정해진 루틴을 철저히 따름" },
                      { value: "adventurous", label: "모험적", desc: "새로운 운동과 도전을 즐김" },
                    ].map((personality) => (
                      <div key={personality.value} className="flex items-center space-x-2 p-3 border rounded-lg hover:bg-blue-50 cursor-pointer">
                        <RadioGroupItem value={personality.value} id={personality.value} />
                        <Label htmlFor={personality.value} className="cursor-pointer flex-1">
                          <p>{personality.label}</p>
                          <p className="text-sm text-gray-500">{personality.desc}</p>
                        </Label>
                      </div>
                    ))}
                  </div>
                </RadioGroup>
              </div>

              <div className="p-4 bg-gradient-to-r from-blue-50 to-sky-50 rounded-xl border border-blue-200">
                <Heart className="w-6 h-6 text-blue-600 mb-2" />
                <p className="text-sm text-gray-700 mb-2">
                  <strong>거의 다 끝났어요! 🎉</strong>
                </p>
                <p className="text-sm text-gray-600">
                  이제 HealCat이 당신만을 위한 완벽한 건강 계획을 만들어드릴 준비가 되었습니다. 
                  당신의 감정, 라이프스타일, 목표를 모두 고려한 맞춤형 추천을 받으실 수 있어요!
                </p>
              </div>
            </div>
          )}
        </div>

        <div className="flex gap-2 mt-6">
          {step > 1 && (
            <Button variant="outline" onClick={handleBack} className="flex-1 border-blue-200">
              이전
            </Button>
          )}
          <Button 
            onClick={handleNext} 
            disabled={!canProceed()} 
            className="flex-1 bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white"
          >
            {step === totalSteps ? "🎉 완료하고 시작하기" : "다음"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
