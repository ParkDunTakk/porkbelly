import { Card } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { Clock, Flame, Dumbbell, Heart, CheckCircle2, Play } from "lucide-react";
import { useState } from "react";

interface Exercise {
  name: string;
  duration: string;
  calories: number;
  sets?: string;
}

interface Routine {
  id: string;
  title: string;
  description: string;
  difficulty: "초급" | "중급" | "고급";
  duration: number;
  calories: number;
  exercises: Exercise[];
  recommended: boolean;
}

export function RoutineRecommendation({ imageUrl }: { imageUrl: string }) {
  const [activeRoutine, setActiveRoutine] = useState<string | null>(null);

  const routines: Routine[] = [
    {
      id: "1",
      title: "아침 에너지 부스터",
      description: "하루를 활기차게 시작하는 가벼운 운동",
      difficulty: "초급",
      duration: 20,
      calories: 150,
      recommended: true,
      exercises: [
        { name: "팔 벌려 뛰기", duration: "3분", calories: 30 },
        { name: "하이 니", duration: "3분", calories: 35 },
        { name: "버피", duration: "2분", calories: 40, sets: "3세트" },
        { name: "플랭크", duration: "2분", calories: 25 },
        { name: "스쿼트", duration: "3분", calories: 20, sets: "15회 x 2세트" }
      ]
    },
    {
      id: "2",
      title: "근력 향상 프로그램",
      description: "체계적인 근육 발달을 위한 중급 루틴",
      difficulty: "중급",
      duration: 45,
      calories: 320,
      recommended: true,
      exercises: [
        { name: "푸쉬업", duration: "5분", calories: 50, sets: "12회 x 3세트" },
        { name: "스쿼트", duration: "5분", calories: 60, sets: "15회 x 3세트" },
        { name: "런지", duration: "5분", calories: 55, sets: "12회 x 3세트" },
        { name: "플랭크", duration: "3분", calories: 40 },
        { name: "덤벨 로우", duration: "5분", calories: 65, sets: "10회 x 3세트" },
        { name: "사이드 플랭크", duration: "4분", calories: 50 }
      ]
    },
    {
      id: "3",
      title: "저녁 릴렉스 요가",
      description: "하루의 스트레스를 풀어주는 요가 루틴",
      difficulty: "초급",
      duration: 30,
      calories: 100,
      recommended: false,
      exercises: [
        { name: "고양이-소 자세", duration: "3분", calories: 15 },
        { name: "다운독", duration: "5분", calories: 25 },
        { name: "전사 자세", duration: "5분", calories: 30 },
        { name: "비둘기 자세", duration: "5분", calories: 15 },
        { name: "샤바아사나", duration: "5분", calories: 15 }
      ]
    },
    {
      id: "4",
      title: "유산소 지방 연소",
      description: "효과적인 칼로리 소모를 위한 유산소 운동",
      difficulty: "중급",
      duration: 35,
      calories: 400,
      recommended: true,
      exercises: [
        { name: "워밍업 조깅", duration: "5분", calories: 50 },
        { name: "인터벌 러닝", duration: "15분", calories: 180 },
        { name: "마운틴 클라이머", duration: "5분", calories: 80 },
        { name: "점핑 잭", duration: "5분", calories: 60 },
        { name: "쿨다운 스트레칭", duration: "5분", calories: 30 }
      ]
    }
  ];

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "초급":
        return "bg-green-100 text-green-700";
      case "중급":
        return "bg-yellow-100 text-yellow-700";
      case "고급":
        return "bg-red-100 text-red-700";
      default:
        return "bg-gray-100 text-gray-700";
    }
  };

  return (
    <div className="space-y-6">
      <div className="relative rounded-xl overflow-hidden h-48">
        <ImageWithFallback
          src={imageUrl}
          alt="Workout"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-blue-600/90 to-purple-600/90 flex items-center justify-center text-white text-center p-6">
          <div>
            <h2 className="text-3xl mb-2">맞춤 운동 루틴</h2>
            <p className="text-blue-100">당신의 목표와 컨디션에 맞춘 최적의 운동 계획</p>
          </div>
        </div>
      </div>

      <div className="flex items-center justify-between">
        <div>
          <h3 className="mb-1">추천 루틴</h3>
          <p className="text-sm text-gray-600">BMI와 목표를 기반으로 선별됨</p>
        </div>
        <Button variant="outline" size="sm">
          <Heart className="w-4 h-4 mr-2" />
          취향 설정
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {routines.map((routine) => (
          <Card key={routine.id} className="p-5 hover:shadow-lg transition-shadow">
            {routine.recommended && (
              <Badge className="mb-3 bg-gradient-to-r from-blue-500 to-purple-500">
                ⭐ 추천
              </Badge>
            )}
            
            <h4 className="mb-2">{routine.title}</h4>
            <p className="text-sm text-gray-600 mb-4">{routine.description}</p>

            <div className="flex flex-wrap gap-2 mb-4">
              <Badge variant="outline" className={getDifficultyColor(routine.difficulty)}>
                {routine.difficulty}
              </Badge>
              <Badge variant="outline" className="flex items-center gap-1">
                <Clock className="w-3 h-3" />
                {routine.duration}분
              </Badge>
              <Badge variant="outline" className="flex items-center gap-1">
                <Flame className="w-3 h-3" />
                {routine.calories} kcal
              </Badge>
            </div>

            {activeRoutine === routine.id ? (
              <div className="space-y-3 mb-4">
                {routine.exercises.map((exercise, index) => (
                  <div key={index} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                    <div className="flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-gray-400" />
                      <div>
                        <p className="text-sm">{exercise.name}</p>
                        {exercise.sets && (
                          <p className="text-xs text-gray-500">{exercise.sets}</p>
                        )}
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-xs text-gray-600">{exercise.duration}</p>
                      <p className="text-xs text-gray-500">{exercise.calories} kcal</p>
                    </div>
                  </div>
                ))}
              </div>
            ) : null}

            <div className="flex gap-2">
              <Button 
                className="flex-1"
                onClick={() => setActiveRoutine(activeRoutine === routine.id ? null : routine.id)}
              >
                {activeRoutine === routine.id ? (
                  <>
                    <Play className="w-4 h-4 mr-2" />
                    시작하기
                  </>
                ) : (
                  <>
                    <Dumbbell className="w-4 h-4 mr-2" />
                    상세보기
                  </>
                )}
              </Button>
              {activeRoutine === routine.id && (
                <Button 
                  variant="outline"
                  onClick={() => setActiveRoutine(null)}
                >
                  닫기
                </Button>
              )}
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
