import { Card } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { Progress } from "./ui/progress";
import { 
  Trophy, 
  Star, 
  Zap, 
  Target, 
  Award,
  Crown,
  Flame,
  CheckCircle2,
  Lock
} from "lucide-react";

interface BadgeData {
  id: string;
  name: string;
  description: string;
  icon: React.ReactNode;
  unlocked: boolean;
  unlockedDate?: string;
}

interface Challenge {
  id: string;
  title: string;
  description: string;
  progress: number;
  total: number;
  points: number;
  deadline: string;
  completed: boolean;
}

export function GamificationPanel() {
  const userLevel = 12;
  const currentXP = 2450;
  const nextLevelXP = 3000;
  const totalPoints = 15680;
  const streak = 7;

  const badges: BadgeData[] = [
    {
      id: "1",
      name: "첫 걸음",
      description: "첫 운동 완료",
      icon: <Star className="w-6 h-6 text-yellow-500" />,
      unlocked: true,
      unlockedDate: "2025-10-15"
    },
    {
      id: "2",
      name: "일주일 챌린지",
      description: "7일 연속 운동",
      icon: <Flame className="w-6 h-6 text-orange-500" />,
      unlocked: true,
      unlockedDate: "2025-10-28"
    },
    {
      id: "3",
      name: "물 마시기 마스터",
      description: "30일간 수분 목표 달성",
      icon: <Award className="w-6 h-6 text-blue-500" />,
      unlocked: true,
      unlockedDate: "2025-11-01"
    },
    {
      id: "4",
      name: "아침형 인간",
      description: "아침 6시 이전 운동 10회",
      icon: <Crown className="w-6 h-6 text-purple-500" />,
      unlocked: false
    },
    {
      id: "5",
      name: "칼로리 버너",
      description: "1주일간 3000kcal 소모",
      icon: <Zap className="w-6 h-6 text-yellow-500" />,
      unlocked: false
    },
    {
      id: "6",
      name: "요가 마스터",
      description: "요가 루틴 50회 완료",
      icon: <Trophy className="w-6 h-6 text-green-500" />,
      unlocked: false
    }
  ];

  const challenges: Challenge[] = [
    {
      id: "1",
      title: "주간 운동 목표",
      description: "이번 주 5회 운동 완료하기",
      progress: 3,
      total: 5,
      points: 500,
      deadline: "2일 남음",
      completed: false
    },
    {
      id: "2",
      title: "수분 섭취 챌린지",
      description: "매일 2L 물 마시기 (7일)",
      progress: 5,
      total: 7,
      points: 300,
      deadline: "2일 남음",
      completed: false
    },
    {
      id: "3",
      title: "아침 루틴 완성",
      description: "오전 운동 3회 완료",
      progress: 3,
      total: 3,
      points: 400,
      deadline: "완료!",
      completed: true
    },
    {
      id: "4",
      title: "칼로리 챌린지",
      description: "일주일간 2500kcal 소모",
      progress: 1800,
      total: 2500,
      points: 600,
      deadline: "5일 남음",
      completed: false
    }
  ];

  return (
    <div className="space-y-6">
      {/* Level and Points Card */}
      <Card className="p-6 bg-gradient-to-br from-blue-500 to-blue-600 text-white border-none shadow-lg">
        <div className="flex items-center justify-between mb-4">
          <div>
            <p className="text-sm text-blue-100">레벨</p>
            <p className="text-4xl">{userLevel}</p>
          </div>
          <div className="text-right">
            <p className="text-sm text-blue-100">총 포인트</p>
            <p className="text-2xl flex items-center gap-1 justify-end">
              <Trophy className="w-6 h-6" />
              {totalPoints.toLocaleString()}
            </p>
          </div>
        </div>
        
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span>다음 레벨까지</span>
            <span>{currentXP} / {nextLevelXP} XP</span>
          </div>
          <Progress value={(currentXP / nextLevelXP) * 100} className="bg-white/20 h-3" />
        </div>

        <div className="flex gap-4 mt-4 pt-4 border-t border-white/20">
          <div className="flex items-center gap-2">
            <Flame className="w-5 h-5 text-orange-300" />
            <div>
              <p className="text-xs opacity-75">연속 기록</p>
              <p className="text-lg">{streak}일</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Award className="w-5 h-5 text-yellow-300" />
            <div>
              <p className="text-xs opacity-75">획득 배지</p>
              <p className="text-lg">{badges.filter(b => b.unlocked).length} / {badges.length}</p>
            </div>
          </div>
        </div>
      </Card>

      {/* Challenges */}
      <Card className="p-6 border-blue-100 shadow-md">
        <div className="flex items-center justify-between mb-4">
          <h3 className="flex items-center gap-2 text-gray-800">
            <Target className="w-5 h-5 text-blue-500" />
            진행 중인 챌린지
          </h3>
          <Button variant="outline" size="sm" className="border-blue-200 hover:bg-blue-50 hover:border-blue-300">전체보기</Button>
        </div>

        <div className="space-y-3">
          {challenges.map((challenge) => (
            <div
              key={challenge.id}
              className={`p-4 rounded-2xl border ${
                challenge.completed ? "bg-blue-50 border-blue-200" : "bg-white border-blue-100"
              }`}
            >
              <div className="flex items-start justify-between mb-2">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <h4 className="text-sm text-gray-800">{challenge.title}</h4>
                    {challenge.completed && (
                      <CheckCircle2 className="w-4 h-4 text-blue-600" />
                    )}
                  </div>
                  <p className="text-xs text-gray-600">{challenge.description}</p>
                </div>
                <Badge variant={challenge.completed ? "default" : "secondary"} className={challenge.completed ? "ml-2 bg-blue-500" : "ml-2 bg-gray-200 text-gray-700"}>
                  +{challenge.points}
                </Badge>
              </div>

              <div className="space-y-1">
                <div className="flex justify-between text-xs text-gray-600">
                  <span>
                    {challenge.progress} / {challenge.total}
                  </span>
                  <span className={challenge.completed ? "text-green-600" : "text-blue-600"}>
                    {challenge.deadline}
                  </span>
                </div>
                <Progress value={(challenge.progress / challenge.total) * 100} className="h-2" />
              </div>
            </div>
          ))}
        </div>
      </Card>

      {/* Badges */}
      <Card className="p-6 border-gray-200 shadow-sm">
        <div className="flex items-center justify-between mb-4">
          <h3 className="flex items-center gap-2 text-gray-800">
            <Award className="w-5 h-5 text-amber-500" />
            배지 컬렉션
          </h3>
        </div>

        <div className="grid grid-cols-3 gap-4">
          {badges.map((badge) => (
            <div
              key={badge.id}
              className={`relative p-4 rounded-2xl border text-center transition-all ${
                badge.unlocked
                  ? "bg-amber-50 border-amber-200 hover:shadow-md"
                  : "bg-gray-50 border-gray-200 opacity-60"
              }`}
            >
              {!badge.unlocked && (
                <div className="absolute inset-0 flex items-center justify-center bg-white/80 rounded-2xl">
                  <Lock className="w-6 h-6 text-gray-400" />
                </div>
              )}
              <div className="flex justify-center mb-2">
                {badge.icon}
              </div>
              <p className="text-sm mb-1 text-gray-800">{badge.name}</p>
              <p className="text-xs text-gray-600">{badge.description}</p>
              {badge.unlocked && badge.unlockedDate && (
                <p className="text-xs text-gray-500 mt-2">{badge.unlockedDate}</p>
              )}
            </div>
          ))}
        </div>
      </Card>

      {/* Daily Bonus */}
      <Card className="p-6 bg-amber-50 border-amber-200 shadow-sm">
        <div className="flex items-center gap-4">
          <div className="p-3 bg-amber-500 rounded-full">
            <Zap className="w-6 h-6 text-white" />
          </div>
          <div className="flex-1">
            <h4 className="text-gray-800">일일 보너스 포인트</h4>
            <p className="text-sm text-gray-600">
              오늘의 운동을 완료하고 +200 포인트를 받으세요!
            </p>
          </div>
          <Button className="bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white shadow-sm">시작하기</Button>
        </div>
      </Card>
    </div>
  );
}
