import { Card } from "./ui/card";
import { Button } from "./ui/button";
import { Avatar } from "./ui/avatar";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { Calendar, Clock, Video, MapPin } from "lucide-react";

interface Appointment {
  id: number;
  doctor: string;
  specialty: string;
  date: string;
  time: string;
  type: "video" | "office";
  location?: string;
}

export function AppointmentList({ imageUrl }: { imageUrl: string }) {
  const appointments: Appointment[] = [
    {
      id: 1,
      doctor: "김지은 박사",
      specialty: "내과 전문의",
      date: "2025년 11월 5일",
      time: "10:00 AM",
      type: "video",
    },
    {
      id: 2,
      doctor: "이승호 박사",
      specialty: "정형외과 전문의",
      date: "2025년 11월 8일",
      time: "2:30 PM",
      type: "office",
      location: "서울 강남구 테헤란로 123"
    },
    {
      id: 3,
      doctor: "박민지 박사",
      specialty: "피부과 전문의",
      date: "2025년 11월 12일",
      time: "11:00 AM",
      type: "office",
      location: "서울 서초구 서초대로 456"
    }
  ];

  return (
    <Card className="p-6">
      <div className="flex items-center justify-between mb-6">
        <h3>예정된 진료</h3>
        <Button variant="outline" size="sm">
          <Calendar className="w-4 h-4 mr-2" />
          새 예약
        </Button>
      </div>

      <div className="space-y-4">
        {appointments.map((appointment) => (
          <div key={appointment.id} className="p-4 border rounded-lg hover:shadow-md transition-shadow">
            <div className="flex items-start gap-4">
              <Avatar className="w-12 h-12">
                <ImageWithFallback
                  src={imageUrl}
                  alt={appointment.doctor}
                  className="w-full h-full object-cover"
                />
              </Avatar>
              
              <div className="flex-1">
                <div className="flex items-start justify-between mb-2">
                  <div>
                    <h4 className="mb-1">{appointment.doctor}</h4>
                    <p className="text-sm text-gray-500">{appointment.specialty}</p>
                  </div>
                  {appointment.type === "video" ? (
                    <div className="flex items-center gap-1 px-2 py-1 bg-blue-50 rounded text-sm text-blue-600">
                      <Video className="w-4 h-4" />
                      화상 진료
                    </div>
                  ) : (
                    <div className="flex items-center gap-1 px-2 py-1 bg-green-50 rounded text-sm text-green-600">
                      <MapPin className="w-4 h-4" />
                      방문 진료
                    </div>
                  )}
                </div>

                <div className="flex items-center gap-4 text-sm text-gray-600 mb-3">
                  <span className="flex items-center gap-1">
                    <Calendar className="w-4 h-4" />
                    {appointment.date}
                  </span>
                  <span className="flex items-center gap-1">
                    <Clock className="w-4 h-4" />
                    {appointment.time}
                  </span>
                </div>

                {appointment.location && (
                  <p className="text-sm text-gray-500 mb-3">{appointment.location}</p>
                )}

                <div className="flex gap-2">
                  <Button size="sm" className="flex-1">확인</Button>
                  <Button size="sm" variant="outline">변경</Button>
                  <Button size="sm" variant="ghost">취소</Button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </Card>
  );
}
