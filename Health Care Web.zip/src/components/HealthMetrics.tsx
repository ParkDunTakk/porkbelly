import { Card } from "./ui/card";
import { Progress } from "./ui/progress";
import { Heart, Activity, Droplet, Moon } from "lucide-react";

interface MetricCardProps {
  icon: React.ReactNode;
  title: string;
  value: string;
  unit: string;
  progress: number;
  color: string;
}

function MetricCard({ icon, title, value, unit, progress, color }: MetricCardProps) {
  return (
    <Card className="p-6">
      <div className="flex items-start justify-between mb-4">
        <div className={`p-3 rounded-lg ${color}`}>
          {icon}
        </div>
        <span className="text-sm text-gray-500">{title}</span>
      </div>
      <div className="space-y-2">
        <div className="flex items-baseline gap-1">
          <span className="text-3xl">{value}</span>
          <span className="text-sm text-gray-500">{unit}</span>
        </div>
        <Progress value={progress} className="h-2" />
      </div>
    </Card>
  );
}

export function HealthMetrics() {
  const metrics = [
    {
      icon: <Heart className="w-6 h-6 text-red-500" />,
      title: "심박수",
      value: "72",
      unit: "bpm",
      progress: 72,
      color: "bg-red-50"
    },
    {
      icon: <Activity className="w-6 h-6 text-blue-500" />,
      title: "혈압",
      value: "120/80",
      unit: "mmHg",
      progress: 85,
      color: "bg-blue-50"
    },
    {
      icon: <Droplet className="w-6 h-6 text-cyan-500" />,
      title: "수분 섭취",
      value: "1.8",
      unit: "L",
      progress: 60,
      color: "bg-cyan-50"
    },
    {
      icon: <Moon className="w-6 h-6 text-purple-500" />,
      title: "수면",
      value: "7.5",
      unit: "시간",
      progress: 75,
      color: "bg-purple-50"
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
      {metrics.map((metric, index) => (
        <MetricCard key={index} {...metric} />
      ))}
    </div>
  );
}
