import { Card } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { 
  LineChart, 
  Line, 
  BarChart, 
  Bar, 
  AreaChart,
  Area,
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar
} from "recharts";
import { 
  TrendingUp, 
  TrendingDown, 
  Download, 
  Calendar,
  Droplet,
  Moon,
  Utensils,
  Activity,
  Target,
  Award,
  Trophy
} from "lucide-react";

export function WeeklyReport() {
  const waterData = [
    { day: "월", amount: 2.1, goal: 2.0 },
    { day: "화", amount: 1.8, goal: 2.0 },
    { day: "수", amount: 2.3, goal: 2.0 },
    { day: "목", amount: 1.9, goal: 2.0 },
    { day: "금", amount: 2.2, goal: 2.0 },
    { day: "토", amount: 2.5, goal: 2.0 },
    { day: "일", amount: 2.0, goal: 2.0 },
  ];

  const sleepData = [
    { day: "월", hours: 7.5, quality: 85 },
    { day: "화", hours: 6.8, quality: 70 },
    { day: "수", hours: 8.2, quality: 92 },
    { day: "목", hours: 7.0, quality: 78 },
    { day: "금", hours: 6.5, quality: 65 },
    { day: "토", hours: 8.5, quality: 95 },
    { day: "일", hours: 7.8, quality: 88 },
  ];

  const caloriesData = [
    { day: "월", intake: 2100, burned: 420, net: 1680 },
    { day: "화", intake: 1950, burned: 380, net: 1570 },
    { day: "수", intake: 2250, burned: 520, net: 1730 },
    { day: "목", intake: 2050, burned: 450, net: 1600 },
    { day: "금", intake: 2200, burned: 490, net: 1710 },
    { day: "토", intake: 2400, burned: 610, net: 1790 },
    { day: "일", intake: 2000, burned: 380, net: 1620 },
  ];

  const activityData = [
    { day: "월", steps: 8200, distance: 6.1, active: 45 },
    { day: "화", steps: 7500, distance: 5.6, active: 38 },
    { day: "수", steps: 9800, distance: 7.3, active: 52 },
    { day: "목", steps: 8600, distance: 6.4, active: 48 },
    { day: "금", steps: 9200, distance: 6.9, active: 50 },
    { day: "토", steps: 11500, distance: 8.6, active: 65 },
    { day: "일", steps: 7200, distance: 5.4, active: 35 },
  ];

  const overallScore = [
    { category: "운동", score: 85, fullMark: 100 },
    { category: "수면", score: 78, fullMark: 100 },
    { category: "영양", score: 82, fullMark: 100 },
    { category: "수분", score: 90, fullMark: 100 },
    { category: "활동", score: 75, fullMark: 100 }
  ];

  const weeklyAvg = {
    water: 2.11,
    sleep: 7.47,
    calories: 2136,
    burned: 464,
    steps: 8857
  };

  const compareLastWeek = {
    water: +5.5,
    sleep: +3.2,
    calories: -2.1,
    burned: +12.3,
    steps: +8.7
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card className="p-6 bg-emerald-500 text-white border-none shadow-sm">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-2xl mb-1">주간 건강 리포트</h2>
            <p className="text-sm text-emerald-100">2025년 10월 27일 - 11월 2일</p>
          </div>
          <Button variant="secondary" size="sm" className="bg-white/20 hover:bg-white/30 text-white border-none">
            <Download className="w-4 h-4 mr-2" />
            PDF 다운로드
          </Button>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
          <div className="bg-white/10 backdrop-blur rounded-xl p-3">
            <div className="flex items-center gap-2 mb-1">
              <Droplet className="w-4 h-4" />
              <p className="text-xs">평균 수분</p>
            </div>
            <p className="text-2xl">{weeklyAvg.water}L</p>
            <div className="flex items-center gap-1 text-xs mt-1">
              <TrendingUp className="w-3 h-3" />
              <span>+{compareLastWeek.water}%</span>
            </div>
          </div>

          <div className="bg-white/10 backdrop-blur rounded-xl p-3">
            <div className="flex items-center gap-2 mb-1">
              <Moon className="w-4 h-4" />
              <p className="text-xs">평균 수면</p>
            </div>
            <p className="text-2xl">{weeklyAvg.sleep}h</p>
            <div className="flex items-center gap-1 text-xs mt-1">
              <TrendingUp className="w-3 h-3" />
              <span>+{compareLastWeek.sleep}%</span>
            </div>
          </div>

          <div className="bg-white/10 backdrop-blur rounded-xl p-3">
            <div className="flex items-center gap-2 mb-1">
              <Utensils className="w-4 h-4" />
              <p className="text-xs">평균 섭취</p>
            </div>
            <p className="text-2xl">{weeklyAvg.calories}</p>
            <div className="flex items-center gap-1 text-xs mt-1">
              <TrendingDown className="w-3 h-3" />
              <span>{compareLastWeek.calories}%</span>
            </div>
          </div>

          <div className="bg-white/10 backdrop-blur rounded-xl p-3">
            <div className="flex items-center gap-2 mb-1">
              <Activity className="w-4 h-4" />
              <p className="text-xs">소모 칼로리</p>
            </div>
            <p className="text-2xl">{weeklyAvg.burned}</p>
            <div className="flex items-center gap-1 text-xs mt-1">
              <TrendingUp className="w-3 h-3" />
              <span>+{compareLastWeek.burned}%</span>
            </div>
          </div>

          <div className="bg-white/10 backdrop-blur rounded-xl p-3">
            <div className="flex items-center gap-2 mb-1">
              <Target className="w-4 h-4" />
              <p className="text-xs">평균 걸음</p>
            </div>
            <p className="text-2xl">{weeklyAvg.steps.toLocaleString()}</p>
            <div className="flex items-center gap-1 text-xs mt-1">
              <TrendingUp className="w-3 h-3" />
              <span>+{compareLastWeek.steps}%</span>
            </div>
          </div>
        </div>
      </Card>

      {/* Overall Health Score */}
      <Card className="p-6">
        <h3 className="mb-4 flex items-center gap-2">
          <Award className="w-5 h-5 text-yellow-500" />
          종합 건강 점수
        </h3>
        <div className="h-[300px]">
          <ResponsiveContainer width="100%" height="100%">
            <RadarChart data={overallScore}>
              <PolarGrid stroke="#e5e7eb" />
              <PolarAngleAxis dataKey="category" />
              <PolarRadiusAxis angle={90} domain={[0, 100]} />
              <Radar name="점수" dataKey="score" stroke="#8b5cf6" fill="#8b5cf6" fillOpacity={0.6} />
            </RadarChart>
          </ResponsiveContainer>
        </div>
        <div className="grid grid-cols-5 gap-2 mt-4">
          {overallScore.map((item) => (
            <div key={item.category} className="text-center">
              <p className="text-2xl text-purple-600">{item.score}</p>
              <p className="text-xs text-gray-600">{item.category}</p>
            </div>
          ))}
        </div>
      </Card>

      {/* Detailed Charts */}
      <Tabs defaultValue="water" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="water">
            <Droplet className="w-4 h-4 mr-2" />
            수분
          </TabsTrigger>
          <TabsTrigger value="sleep">
            <Moon className="w-4 h-4 mr-2" />
            수면
          </TabsTrigger>
          <TabsTrigger value="calories">
            <Utensils className="w-4 h-4 mr-2" />
            칼로리
          </TabsTrigger>
          <TabsTrigger value="activity">
            <Activity className="w-4 h-4 mr-2" />
            활동
          </TabsTrigger>
        </TabsList>

        <TabsContent value="water">
          <Card className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h4>일일 수분 섭취량</h4>
              <Badge>목표: 2.0L/일</Badge>
            </div>
            <div className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={waterData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                  <XAxis dataKey="day" />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="amount" fill="#06b6d4" radius={[8, 8, 0, 0]} />
                  <Line type="monotone" dataKey="goal" stroke="#f97316" strokeDasharray="5 5" />
                </BarChart>
              </ResponsiveContainer>
            </div>
            <div className="mt-4 p-4 bg-cyan-50 rounded-lg">
              <p className="text-sm">
                <strong>인사이트:</strong> 이번 주 평균 수분 섭취량이 목표를 초과했어요! 훌륭합니다 💧
                특히 토요일에 2.5L를 달성하셨네요. 계속 이 페이스를 유지하세요!
              </p>
            </div>
          </Card>
        </TabsContent>

        <TabsContent value="sleep">
          <Card className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h4>수면 시간 및 품질</h4>
              <Badge>권장: 7-8시간</Badge>
            </div>
            <div className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={sleepData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                  <XAxis dataKey="day" />
                  <YAxis yAxisId="left" />
                  <YAxis yAxisId="right" orientation="right" />
                  <Tooltip />
                  <Area 
                    yAxisId="left"
                    type="monotone" 
                    dataKey="hours" 
                    stroke="#8b5cf6" 
                    fill="#c4b5fd" 
                    name="수면 시간"
                  />
                  <Line 
                    yAxisId="right"
                    type="monotone" 
                    dataKey="quality" 
                    stroke="#f59e0b" 
                    name="수면 품질"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
            <div className="mt-4 p-4 bg-purple-50 rounded-lg">
              <p className="text-sm">
                <strong>인사이트:</strong> 주말에 수면 시간과 품질이 모두 향상되었어요 😴
                평일에는 평균 6.9시간으로 조금 부족합니다. 취침 시간을 30분 앞당겨보는 것을 추천해요.
              </p>
            </div>
          </Card>
        </TabsContent>

        <TabsContent value="calories">
          <Card className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h4>칼로리 섭취 vs 소모</h4>
              <div className="flex gap-2">
                <Badge variant="outline" className="bg-green-50">섭취</Badge>
                <Badge variant="outline" className="bg-red-50">소모</Badge>
              </div>
            </div>
            <div className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={caloriesData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                  <XAxis dataKey="day" />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="intake" fill="#10b981" radius={[8, 8, 0, 0]} />
                  <Bar dataKey="burned" fill="#ef4444" radius={[8, 8, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
            <div className="mt-4 p-4 bg-green-50 rounded-lg">
              <p className="text-sm">
                <strong>인사이트:</strong> 일평균 순 칼로리는 1671 kcal입니다 🍽️
                체중 감량 목표에 적합한 수준을 유지하고 있어요. 토요일에 가장 많은 칼로리를 소모했네요!
              </p>
            </div>
          </Card>
        </TabsContent>

        <TabsContent value="activity">
          <Card className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h4>일일 활동량</h4>
              <Badge>목표: 10,000 걸음</Badge>
            </div>
            <div className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={activityData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                  <XAxis dataKey="day" />
                  <YAxis yAxisId="left" />
                  <YAxis yAxisId="right" orientation="right" />
                  <Tooltip />
                  <Line 
                    yAxisId="left"
                    type="monotone" 
                    dataKey="steps" 
                    stroke="#3b82f6" 
                    strokeWidth={2}
                    dot={{ fill: '#3b82f6', r: 4 }}
                  />
                  <Line 
                    yAxisId="right"
                    type="monotone" 
                    dataKey="active" 
                    stroke="#f59e0b" 
                    strokeWidth={2}
                    dot={{ fill: '#f59e0b', r: 4 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
            <div className="mt-4 p-4 bg-blue-50 rounded-lg">
              <p className="text-sm">
                <strong>인사이트:</strong> 토요일에 11,500걸음으로 주간 최고 기록을 달성했어요! 🎉
                평균 8,857걸음으로 목표에 조금 못 미쳤지만, 지난 주 대비 8.7% 증가했습니다. 계속 화이팅!
              </p>
            </div>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Achievements This Week */}
      <Card className="p-6">
        <h3 className="mb-4">이번 주 성과</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="p-4 bg-gradient-to-br from-green-50 to-emerald-50 rounded-lg border border-green-200">
            <div className="flex items-center gap-2 mb-2">
              <Award className="w-5 h-5 text-green-600" />
              <h4 className="text-sm">완벽한 한 주</h4>
            </div>
            <p className="text-xs text-gray-600">7일 연속 건강 목표 달성</p>
          </div>
          
          <div className="p-4 bg-gradient-to-br from-blue-50 to-cyan-50 rounded-lg border border-blue-200">
            <div className="flex items-center gap-2 mb-2">
              <Trophy className="w-5 h-5 text-blue-600" />
              <h4 className="text-sm">최고 기록</h4>
            </div>
            <p className="text-xs text-gray-600">주간 걸음 수 신기록 달성</p>
          </div>

          <div className="p-4 bg-gradient-to-br from-purple-50 to-pink-50 rounded-lg border border-purple-200">
            <div className="flex items-center gap-2 mb-2">
              <Target className="w-5 h-5 text-purple-600" />
              <h4 className="text-sm">목표 달성률</h4>
            </div>
            <p className="text-xs text-gray-600">85% - 지난 주 대비 +12%</p>
          </div>
        </div>
      </Card>
    </div>
  );
}
