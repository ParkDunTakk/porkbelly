import { Card } from "./ui/card";
import { Button } from "./ui/button";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { Plus, Apple } from "lucide-react";

interface MealProps {
  type: string;
  time: string;
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  items: string[];
}

function MealCard({ type, time, calories, protein, carbs, fat, items }: MealProps) {
  return (
    <div className="p-4 border rounded-lg">
      <div className="flex items-center justify-between mb-3">
        <div>
          <h4>{type}</h4>
          <p className="text-sm text-gray-500">{time}</p>
        </div>
        <div className="text-right">
          <p className="text-lg">{calories}</p>
          <p className="text-sm text-gray-500">kcal</p>
        </div>
      </div>
      
      <div className="grid grid-cols-3 gap-2 mb-3 text-sm">
        <div className="p-2 bg-red-50 rounded text-center">
          <p className="text-gray-600">단백질</p>
          <p className="text-red-600">{protein}g</p>
        </div>
        <div className="p-2 bg-yellow-50 rounded text-center">
          <p className="text-gray-600">탄수화물</p>
          <p className="text-yellow-600">{carbs}g</p>
        </div>
        <div className="p-2 bg-blue-50 rounded text-center">
          <p className="text-gray-600">지방</p>
          <p className="text-blue-600">{fat}g</p>
        </div>
      </div>

      <div className="space-y-1">
        {items.map((item, index) => (
          <p key={index} className="text-sm text-gray-600">• {item}</p>
        ))}
      </div>
    </div>
  );
}

export function NutritionTracker({ imageUrl }: { imageUrl: string }) {
  const meals: MealProps[] = [
    {
      type: "아침",
      time: "08:00 AM",
      calories: 420,
      protein: 25,
      carbs: 45,
      fat: 12,
      items: ["귀리 오트밀", "바나나", "아몬드", "그릭 요거트"]
    },
    {
      type: "점심",
      time: "12:30 PM",
      calories: 650,
      protein: 38,
      carbs: 72,
      fat: 18,
      items: ["현미밥", "닭가슴살 샐러드", "브로콜리", "고구마"]
    },
    {
      type: "저녁",
      time: "07:00 PM",
      calories: 580,
      protein: 32,
      carbs: 58,
      fat: 22,
      items: ["연어 구이", "퀴노아", "아스파라거스", "아보카도"]
    }
  ];

  const dailyTotal = {
    calories: 1650,
    target: 2000,
    protein: 95,
    carbs: 175,
    fat: 52
  };

  return (
    <Card className="p-6">
      <div className="flex items-center justify-between mb-6">
        <h3>영양 관리</h3>
        <Button size="sm">
          <Plus className="w-4 h-4 mr-2" />
          식사 추가
        </Button>
      </div>

      <div className="mb-6 p-4 bg-gradient-to-r from-green-50 to-emerald-50 rounded-lg">
        <div className="flex items-center gap-3 mb-3">
          <Apple className="w-6 h-6 text-green-600" />
          <div>
            <p className="text-sm text-gray-600">오늘 섭취한 칼로리</p>
            <p className="text-2xl">{dailyTotal.calories} / {dailyTotal.target} kcal</p>
          </div>
        </div>
        <div className="w-full bg-white rounded-full h-3">
          <div 
            className="bg-green-500 h-3 rounded-full transition-all"
            style={{ width: `${(dailyTotal.calories / dailyTotal.target) * 100}%` }}
          />
        </div>
      </div>

      <div className="relative mb-6 rounded-lg overflow-hidden h-32">
        <ImageWithFallback
          src={imageUrl}
          alt="Healthy food"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end p-4">
          <p className="text-white">균형잡힌 식단으로 건강한 하루를 시작하세요</p>
        </div>
      </div>

      <div className="space-y-4">
        {meals.map((meal, index) => (
          <MealCard key={index} {...meal} />
        ))}
      </div>
    </Card>
  );
}
