import { useState, useEffect } from "react";
import { Card } from "./ui/card";
import { Button } from "./ui/button";
import { Progress } from "./ui/progress";
import { Badge } from "./ui/badge";
import { Slider } from "./ui/slider";
import { 
  Droplet, 
  Moon, 
  Apple, 
  Plus, 
  Check,
  TrendingUp,
  Clock,
  Smile,
  Frown,
  Meh,
  Save
} from "lucide-react";
import { apiCall } from "../utils/supabase/client";
import { toast } from "sonner@2.0.3";

interface DailyTrackerProps {
  accessToken?: string;
}

export function DailyTracker({ accessToken }: DailyTrackerProps) {
  const [waterGlasses, setWaterGlasses] = useState(0);
  const [sleepHours, setSleepHours] = useState([7.5]);
  const [meals, setMeals] = useState({ breakfast: false, lunch: false, dinner: false });
  const [mood, setMood] = useState<"great" | "okay" | "tired">("okay");
  const [isLoading, setIsLoading] = useState(false);
  const [lastSaved, setLastSaved] = useState<Date | null>(null);

  const waterGoal = 8;
  const sleepGoal = 8;

  // 오늘의 활동 데이터 불러오기
  useEffect(() => {
    loadTodayActivity();
  }, []);

  const loadTodayActivity = async () => {
    try {
      const today = new Date().toISOString().split('T')[0];
      const result = await apiCall(`/daily-activity/${today}`);
      
      if (result.activity) {
        setWaterGlasses(result.activity.water_glasses || 0);
        setSleepHours([result.activity.sleep_hours || 7.5]);
        setMeals({
          breakfast: result.activity.breakfast || false,
          lunch: result.activity.lunch || false,
          dinner: result.activity.dinner || false,
        });
        setMood(result.activity.mood || "okay");
        setLastSaved(new Date(result.activity.created_at));
      }
    } catch (error) {
      console.error('오늘의 활동 불러오기 실패:', error);
    }
  };

  // 데이터 자동 저장 (변경될 때마다)
  useEffect(() => {
    const timeoutId = setTimeout(() => {
      saveTodayActivity();
    }, 1000); // 1초 디바운스

    return () => clearTimeout(timeoutId);
  }, [waterGlasses, sleepHours, meals, mood]);

  const saveTodayActivity = async () => {
    try {
      setIsLoading(true);
      
      const mealsCompleted = Object.values(meals).filter(Boolean).length;
      
      await apiCall('/daily-activity', {
        method: 'POST',
        body: JSON.stringify({
          water_glasses: waterGlasses,
          sleep_hours: sleepHours[0],
          breakfast: meals.breakfast,
          lunch: meals.lunch,
          dinner: meals.dinner,
          meals_completed: mealsCompleted,
          mood: mood,
        }),
      });

      setLastSaved(new Date());
    } catch (error) {
      console.error('활동 저장 실패:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const addWaterGlass = () => {
    if (waterGlasses < 12) {
      setWaterGlasses(waterGlasses + 1);
      if (waterGlasses + 1 === waterGoal) {
        toast.success("🎉 오늘 수분 섭취 목표 달성!");
      }
    }
  };

  const toggleMeal = (mealType: keyof typeof meals) => {
    setMeals({ ...meals, [mealType]: !meals[mealType] });
    if (!meals[mealType]) {
      toast.success(`${mealType === 'breakfast' ? '아침' : mealType === 'lunch' ? '점심' : '저녁'} 식사 기록 완료!`);
    }
  };

  const handleMoodChange = (newMood: "great" | "okay" | "tired") => {
    setMood(newMood);
    const moodText = newMood === "great" ? "좋아요" : newMood === "okay" ? "보통" : "피곤해요";
    toast.success(`오늘 기분: ${moodText}`);
  };

  return (
    <div className="space-y-4">
      {/* Daily Mood */}
      <Card className="p-5">
        <h4 className="mb-4">오늘 기분은 어떤가요?</h4>
        <div className="grid grid-cols-3 gap-3">
          <button
            onClick={() => handleMoodChange("great")}
            className={`p-4 rounded-lg border-2 transition-all ${
              mood === "great"
                ? "border-green-500 bg-green-50"
                : "border-gray-200 hover:border-gray-300"
            }`}
          >
            <Smile className={`w-8 h-8 mx-auto mb-2 ${mood === "great" ? "text-green-500" : "text-gray-400"}`} />
            <p className="text-sm text-center">좋아요</p>
          </button>
          <button
            onClick={() => handleMoodChange("okay")}
            className={`p-4 rounded-lg border-2 transition-all ${
              mood === "okay"
                ? "border-yellow-500 bg-yellow-50"
                : "border-gray-200 hover:border-gray-300"
            }`}
          >
            <Meh className={`w-8 h-8 mx-auto mb-2 ${mood === "okay" ? "text-yellow-500" : "text-gray-400"}`} />
            <p className="text-sm text-center">보통</p>
          </button>
          <button
            onClick={() => handleMoodChange("tired")}
            className={`p-4 rounded-lg border-2 transition-all ${
              mood === "tired"
                ? "border-red-500 bg-red-50"
                : "border-gray-200 hover:border-gray-300"
            }`}
          >
            <Frown className={`w-8 h-8 mx-auto mb-2 ${mood === "tired" ? "text-red-500" : "text-gray-400"}`} />
            <p className="text-sm text-center">피곤해요</p>
          </button>
        </div>
      </Card>

      {/* Water Intake */}
      <Card className="p-5">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Droplet className="w-5 h-5 text-blue-500" />
            <h4>수분 섭취</h4>
          </div>
          <Badge variant={waterGlasses >= waterGoal ? "default" : "secondary"}>
            {waterGlasses} / {waterGoal} 잔
          </Badge>
        </div>

        <div className="space-y-4">
          <Progress value={(waterGlasses / waterGoal) * 100} className="h-3" />
          
          <div className="grid grid-cols-8 gap-2">
            {Array.from({ length: 8 }).map((_, i) => (
              <button
                key={i}
                onClick={() => setWaterGlasses(i + 1)}
                className={`aspect-square rounded-lg border-2 transition-all ${
                  i < waterGlasses
                    ? "bg-blue-500 border-blue-500"
                    : "border-gray-200 hover:border-blue-300"
                }`}
              >
                <Droplet
                  className={`w-4 h-4 mx-auto ${
                    i < waterGlasses ? "text-white" : "text-gray-300"
                  }`}
                />
              </button>
            ))}
          </div>

          <Button onClick={addWaterGlass} variant="outline" className="w-full">
            <Plus className="w-4 h-4 mr-2" />
            물 한 잔 추가 (250ml)
          </Button>

          {waterGlasses >= waterGoal && (
            <div className="p-3 bg-blue-50 rounded-lg flex items-center gap-2">
              <Check className="w-5 h-5 text-blue-600" />
              <p className="text-sm text-blue-800">오늘 수분 섭취 목표를 달성했어요! 🎉</p>
            </div>
          )}
        </div>
      </Card>

      {/* Sleep Tracker */}
      <Card className="p-5">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Moon className="w-5 h-5 text-purple-500" />
            <h4>수면 시간</h4>
          </div>
          <Badge variant={sleepHours[0] >= 7 ? "default" : "secondary"}>
            {sleepHours[0]} 시간
          </Badge>
        </div>

        <div className="space-y-4">
          <div className="space-y-2">
            <Slider
              value={sleepHours}
              onValueChange={setSleepHours}
              max={12}
              min={0}
              step={0.5}
              className="w-full"
            />
            <div className="flex justify-between text-xs text-gray-500">
              <span>0h</span>
              <span>6h</span>
              <span>12h</span>
            </div>
          </div>

          <div className="p-4 bg-purple-50 rounded-lg">
            <div className="flex items-start gap-3">
              <Clock className="w-5 h-5 text-purple-600 flex-shrink-0 mt-1" />
              <div>
                <p className="text-sm mb-1">
                  {sleepHours[0] >= 7 && sleepHours[0] <= 9
                    ? "완벽한 수면 시간이에요! 😴"
                    : sleepHours[0] < 7
                    ? "조금 더 자는 것이 좋아요"
                    : "수면 시간이 너무 길어요"}
                </p>
                <p className="text-xs text-gray-600">권장 수면 시간: 7-9시간</p>
              </div>
            </div>
          </div>
        </div>
      </Card>

      {/* Meal Tracker */}
      <Card className="p-5">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Apple className="w-5 h-5 text-green-500" />
            <h4>식사 기록</h4>
          </div>
          <Badge>
            {Object.values(meals).filter(Boolean).length} / 3 식사
          </Badge>
        </div>

        <div className="space-y-3">
          <button
            onClick={() => toggleMeal("breakfast")}
            className={`w-full p-4 rounded-lg border-2 transition-all text-left ${
              meals.breakfast
                ? "border-green-500 bg-green-50"
                : "border-gray-200 hover:border-gray-300"
            }`}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center ${
                  meals.breakfast ? "border-green-500 bg-green-500" : "border-gray-300"
                }`}>
                  {meals.breakfast && <Check className="w-4 h-4 text-white" />}
                </div>
                <div>
                  <p className="text-sm">아침</p>
                  <p className="text-xs text-gray-500">07:00 - 09:00</p>
                </div>
              </div>
              {meals.breakfast && (
                <TrendingUp className="w-4 h-4 text-green-600" />
              )}
            </div>
          </button>

          <button
            onClick={() => toggleMeal("lunch")}
            className={`w-full p-4 rounded-lg border-2 transition-all text-left ${
              meals.lunch
                ? "border-green-500 bg-green-50"
                : "border-gray-200 hover:border-gray-300"
            }`}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center ${
                  meals.lunch ? "border-green-500 bg-green-500" : "border-gray-300"
                }`}>
                  {meals.lunch && <Check className="w-4 h-4 text-white" />}
                </div>
                <div>
                  <p className="text-sm">점심</p>
                  <p className="text-xs text-gray-500">12:00 - 14:00</p>
                </div>
              </div>
              {meals.lunch && (
                <TrendingUp className="w-4 h-4 text-green-600" />
              )}
            </div>
          </button>

          <button
            onClick={() => toggleMeal("dinner")}
            className={`w-full p-4 rounded-lg border-2 transition-all text-left ${
              meals.dinner
                ? "border-green-500 bg-green-50"
                : "border-gray-200 hover:border-gray-300"
            }`}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center ${
                  meals.dinner ? "border-green-500 bg-green-500" : "border-gray-300"
                }`}>
                  {meals.dinner && <Check className="w-4 h-4 text-white" />}
                </div>
                <div>
                  <p className="text-sm">저녁</p>
                  <p className="text-xs text-gray-500">18:00 - 20:00</p>
                </div>
              </div>
              {meals.dinner && (
                <TrendingUp className="w-4 h-4 text-green-600" />
              )}
            </div>
          </button>
        </div>

        <Button variant="outline" className="w-full mt-3">
          <Plus className="w-4 h-4 mr-2" />
          간식 추가
        </Button>
      </Card>

      {/* Daily Summary */}
      <Card className="p-5 bg-gradient-to-br from-blue-50 to-purple-50">
        <h4 className="mb-3">오늘의 요약</h4>
        <div className="space-y-2 text-sm">
          <div className="flex justify-between">
            <span className="text-gray-600">수분 섭취율</span>
            <span className="text-blue-600">{((waterGlasses / waterGoal) * 100).toFixed(0)}%</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-600">수면 목표 달성</span>
            <span className={sleepHours[0] >= 7 ? "text-green-600" : "text-red-600"}>
              {sleepHours[0] >= 7 ? "✓ 달성" : "✗ 미달"}
            </span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-600">식사 완료</span>
            <span className="text-green-600">
              {Object.values(meals).filter(v => v === true).length} / 3
            </span>
          </div>
        </div>
      </Card>
    </div>
  );
}