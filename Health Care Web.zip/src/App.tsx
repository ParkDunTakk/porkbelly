import { useState, useEffect } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./components/ui/tabs";
import { Button } from "./components/ui/button";
import { Avatar } from "./components/ui/avatar";
import { ImageWithFallback } from "./components/figma/ImageWithFallback";
import { Auth } from "./components/Auth";
import { ChatInterface } from "./components/ChatInterface";
import { OnboardingModal } from "./components/OnboardingModal";
import { RoutineRecommendation } from "./components/RoutineRecommendation";
import { GamificationPanel } from "./components/GamificationPanel";
import { WeeklyReport } from "./components/WeeklyReport";
import { DailyTracker } from "./components/DailyTracker";
import { supabase, apiCall } from "./utils/supabase/client";
import { 
  MessageCircle, 
  Dumbbell, 
  Trophy, 
  BarChart3,
  Calendar,
  Settings,
  Bell,
  Cat,
  LogOut,
  Loader2
} from "lucide-react";
import { Toaster } from "./components/ui/sonner";

export default function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [user, setUser] = useState<any>(null);
  const [session, setSession] = useState<any>(null);
  const [userProfile, setUserProfile] = useState<any>(null);
  const [showOnboarding, setShowOnboarding] = useState(false);
  const [chatStats, setChatStats] = useState({
    totalConversations: 0,
    satisfactionRate: 0
  });

  // 세션 확인
  useEffect(() => {
    checkSession();

    // Auth 상태 변경 리스너
    const { data: authListener } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        if (event === 'SIGNED_IN' && session) {
          setIsAuthenticated(true);
          setUser(session.user);
          setSession(session);
          await loadUserProfile();
          await loadChatStats();
        } else if (event === 'SIGNED_OUT') {
          setIsAuthenticated(false);
          setUser(null);
          setSession(null);
          setUserProfile(null);
        }
      }
    );

    return () => {
      authListener?.subscription.unsubscribe();
    };
  }, []);

  const checkSession = async () => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      
      if (session) {
        setIsAuthenticated(true);
        setUser(session.user);
        setSession(session);
        await loadUserProfile();
        await loadChatStats();
      } else {
        setIsAuthenticated(false);
      }
    } catch (error) {
      console.error('세션 확인 에러:', error);
      setIsAuthenticated(false);
    } finally {
      setIsLoading(false);
    }
  };

  const loadUserProfile = async () => {
    try {
      const result = await apiCall('/profile');
      setUserProfile(result.profile);
      
      // 프로필이 없거나 온보딩 데이터가 없으면 온보딩 표시
      if (!result.profile || !result.profile.height || !result.profile.goal) {
        setShowOnboarding(true);
      }
    } catch (error) {
      console.error('프로필 로드 에러:', error);
      // 프로필이 없으면 온보딩 표시
      setShowOnboarding(true);
    }
  };

  const loadChatStats = async () => {
    try {
      const result = await apiCall('/chat-stats');
      setChatStats({
        totalConversations: result.totalConversations || 0,
        satisfactionRate: result.satisfactionRate || 0
      });
    } catch (error) {
      console.error('채팅 통계 로드 에러:', error);
    }
  };

  const handleOnboardingComplete = async (data: any) => {
    try {
      // 서버에 프로필 업데이트
      await apiCall('/profile', {
        method: 'PUT',
        body: JSON.stringify(data),
      });

      // 프로필 다시 로드
      await loadUserProfile();
      setShowOnboarding(false);
    } catch (error) {
      console.error('온보딩 데이터 저장 에러:', error);
      alert('데이터 저장에 실패했습니다. 다시 시도해주세요.');
    }
  };

  const handleLogout = async () => {
    try {
      await supabase.auth.signOut();
      setIsAuthenticated(false);
      setUser(null);
      setSession(null);
      setUserProfile(null);
    } catch (error) {
      console.error('로그아웃 에러:', error);
    }
  };

  // 로딩 중
  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-sky-50 to-blue-50 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-12 h-12 animate-spin text-blue-500 mx-auto mb-4" />
          <p className="text-gray-600">로딩 중...</p>
        </div>
      </div>
    );
  }

  // 인증되지 않은 경우 로그인/회원가입 화면
  if (!isAuthenticated) {
    return <Auth onAuthSuccess={() => setIsAuthenticated(true)} />;
  }

  const workoutImageUrl = "https://images.unsplash.com/photo-1669989179336-b2234d2878df?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmaXRuZXNzJTIwd29ya291dCUyMG1vdGl2YXRpb258ZW58MXx8fHwxNzYyMDgzMTQwfDA&ixlib=rb-4.1.0&q=80&w=1080";
  const catCharacterUrl = "https://images.unsplash.com/photo-1739513261094-ba34a1c9e307?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjdXRlJTIwY2F0JTIwY2FydG9vbiUyMGNoYXJhY3RlciUyMGlsbHVzdHJhdGlvbnxlbnwxfHx8fDE3NjIxODA4Njh8MA&ixlib=rb-4.1.0&q=80&w=1080";

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-sky-50 to-blue-50">
      {/* Toast notifications */}
      <Toaster position="top-right" />
      
      {/* Header */}
      <header className="bg-white/90 backdrop-blur-md border-b border-blue-100 sticky top-0 z-50 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <div className="relative">
                <div className="w-11 h-11 bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl flex items-center justify-center shadow-md">
                  <Cat className="w-6 h-6 text-white" />
                </div>
                <div className="absolute -top-1 -right-1 w-3.5 h-3.5 bg-sky-400 rounded-full border-2 border-white animate-pulse"></div>
              </div>
              <div>
                <h1 className="text-xl text-gray-800">HealCat</h1>
                <p className="text-xs text-blue-600">당신의 건강 파트너 🐱</p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <Button variant="ghost" size="icon" className="relative hover:bg-blue-50">
                <Bell className="w-5 h-5 text-gray-600" />
                <span className="absolute top-1 right-1 w-2 h-2 bg-blue-500 rounded-full"></span>
              </Button>
              <Button variant="ghost" size="icon" className="hover:bg-blue-50">
                <Settings className="w-5 h-5 text-gray-600" />
              </Button>
              <Avatar className="w-10 h-10 cursor-pointer border-2 border-blue-200 shadow-sm">
                <ImageWithFallback
                  src="https://api.dicebear.com/7.x/avataaars/svg?seed=healcat-user"
                  alt="User"
                  className="w-full h-full"
                />
              </Avatar>
              <Button variant="ghost" size="icon" className="hover:bg-blue-50" onClick={handleLogout}>
                <LogOut className="w-5 h-5 text-gray-600" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <div className="mb-8 text-center">
          <h2 className="text-3xl mb-2 text-gray-800">안녕하세요! 👋</h2>
          <p className="text-gray-600 mb-4">건강한 하루를 HealCat과 함께 시작하세요</p>
          {!userProfile && (
            <Button onClick={() => setShowOnboarding(true)} size="lg" className="bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white shadow-md">
              시작하기 - 맞춤 계획 받기
            </Button>
          )}
        </div>

        {/* Main Tabs */}
        <Tabs defaultValue="chat" className="w-full">
          <TabsList className="grid w-full grid-cols-5 mb-8 h-auto p-1 bg-white/80 backdrop-blur border border-blue-100 shadow-sm">
            <TabsTrigger value="chat" className="flex flex-col sm:flex-row items-center gap-2 py-3 data-[state=active]:bg-blue-50 data-[state=active]:text-blue-700">
              <MessageCircle className="w-5 h-5" />
              <span className="text-xs sm:text-sm">AI 채팅</span>
            </TabsTrigger>
            <TabsTrigger value="routine" className="flex flex-col sm:flex-row items-center gap-2 py-3 data-[state=active]:bg-blue-50 data-[state=active]:text-blue-700">
              <Dumbbell className="w-5 h-5" />
              <span className="text-xs sm:text-sm">루틴 추천</span>
            </TabsTrigger>
            <TabsTrigger value="gamification" className="flex flex-col sm:flex-row items-center gap-2 py-3 data-[state=active]:bg-blue-50 data-[state=active]:text-blue-700">
              <Trophy className="w-5 h-5" />
              <span className="text-xs sm:text-sm">보상</span>
            </TabsTrigger>
            <TabsTrigger value="report" className="flex flex-col sm:flex-row items-center gap-2 py-3 data-[state=active]:bg-blue-50 data-[state=active]:text-blue-700">
              <BarChart3 className="w-5 h-5" />
              <span className="text-xs sm:text-sm">주간 리포트</span>
            </TabsTrigger>
            <TabsTrigger value="tracker" className="flex flex-col sm:flex-row items-center gap-2 py-3 data-[state=active]:bg-blue-50 data-[state=active]:text-blue-700">
              <Calendar className="w-5 h-5" />
              <span className="text-xs sm:text-sm">일일 추적</span>
            </TabsTrigger>
          </TabsList>

          {/* Chat Tab */}
          <TabsContent value="chat" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2">
                <ChatInterface 
                  accessToken={session?.access_token} 
                  onFeedbackSubmitted={loadChatStats}
                  userId={user?.id}
                />
              </div>
              <div>
                <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl p-6 text-white mb-4 shadow-lg">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="relative">
                      <Avatar className="w-14 h-14 border-3 border-white shadow-md">
                        <ImageWithFallback
                          src={catCharacterUrl}
                          alt="HealCat"
                          className="w-full h-full object-cover"
                        />
                      </Avatar>
                      <div className="absolute -bottom-1 -right-1 w-5 h-5 bg-green-400 rounded-full border-2 border-white"></div>
                    </div>
                    <div>
                      <h3 className="text-white">HealCat AI</h3>
                      <p className="text-sm text-blue-100">항상 여기 있어요 💙</p>
                    </div>
                  </div>
                  <p className="text-sm text-blue-50 mb-4">
                    운동, 영양, 수면, 스트레스 관리 등 건강에 관한 모든 것을 물어보세요. 
                    저는 당신의 감정을 이해하는 개인 건강 어시스턴트입니다!
                  </p>
                  <div className="flex gap-2">
                    <div className="flex-1 bg-white/20 backdrop-blur rounded-xl p-3 text-center">
                      <p className="text-xs text-blue-100">대화 수</p>
                      <p className="text-lg">{chatStats.totalConversations}</p>
                    </div>
                    <div className="flex-1 bg-white/20 backdrop-blur rounded-xl p-3 text-center">
                      <p className="text-xs text-blue-100">만족도</p>
                      <p className="text-lg">{chatStats.satisfactionRate}%</p>
                    </div>
                  </div>
                </div>

                <div className="bg-white/90 backdrop-blur rounded-2xl p-5 shadow-md border border-blue-100">
                  <h4 className="mb-3 text-gray-800">인기 질문 🔥</h4>
                  <div className="space-y-2">
                    <button className="w-full text-left p-3 rounded-xl bg-blue-50 hover:bg-blue-100 hover:border-blue-200 border border-transparent transition-all text-sm text-gray-700">
                      💪 효과적인 홈트레이닝 방법은?
                    </button>
                    <button className="w-full text-left p-3 rounded-xl bg-blue-50 hover:bg-blue-100 hover:border-blue-200 border border-transparent transition-all text-sm text-gray-700">
                      🥗 다이어트 식단 추천해줘
                    </button>
                    <button className="w-full text-left p-3 rounded-xl bg-blue-50 hover:bg-blue-100 hover:border-blue-200 border border-transparent transition-all text-sm text-gray-700">
                      😴 불면증 해결 방법은?
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </TabsContent>

          {/* Routine Tab */}
          <TabsContent value="routine">
            <RoutineRecommendation imageUrl={workoutImageUrl} />
          </TabsContent>

          {/* Gamification Tab */}
          <TabsContent value="gamification">
            <GamificationPanel />
          </TabsContent>

          {/* Report Tab */}
          <TabsContent value="report">
            <WeeklyReport />
          </TabsContent>

          {/* Tracker Tab */}
          <TabsContent value="tracker">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2">
                <DailyTracker accessToken={session?.access_token} />
              </div>
              <div className="space-y-4">
                <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl p-6 text-white shadow-lg">
                  <h3 className="text-white mb-2">오늘의 목표</h3>
                  <p className="text-sm text-blue-50 mb-4">
                    매일 작은 목표를 달성하면서 건강한 습관을 만들어가세요
                  </p>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm">물 8잔</span>
                      <span className="text-sm">✓ 완료</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">운동 30분</span>
                      <span className="text-sm">진행중</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">7시간 수면</span>
                      <span className="text-sm">예정</span>
                    </div>
                  </div>
                </div>

                <div className="bg-white/90 backdrop-blur rounded-2xl p-5 shadow-md border border-blue-100">
                  <h4 className="mb-3 text-gray-800">주간 통계 📊</h4>
                  <div className="space-y-3">
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span className="text-gray-600">목표 달성률</span>
                        <span className="text-blue-600">85%</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div className="bg-blue-500 h-2 rounded-full" style={{ width: "85%" }}></div>
                      </div>
                    </div>
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span className="text-gray-600">운동 완료</span>
                        <span className="text-sky-600">5/7일</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div className="bg-sky-500 h-2 rounded-full" style={{ width: "71%" }}></div>
                      </div>
                    </div>
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span className="text-gray-600">수면 품질</span>
                        <span className="text-cyan-600">82%</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div className="bg-cyan-500 h-2 rounded-full" style={{ width: "82%" }}></div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-blue-50 rounded-2xl p-5 border border-blue-200">
                  <h4 className="mb-2 text-gray-800">💡 건강 팁</h4>
                  <p className="text-sm text-gray-700">
                    규칙적인 수면 패턴을 유지하면 전반적인 건강과 기분이 개선됩니다. 
                    매일 같은 시간에 자고 일어나는 습관을 들여보세요!
                  </p>
                </div>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </main>

      {/* Footer */}
      <footer className="border-t border-blue-100 bg-white/80 backdrop-blur mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <Cat className="w-5 h-5 text-blue-600" />
              <p className="text-sm text-gray-600">
                © 2025 HealCat. 건강한 삶을 위한 파트너
              </p>
            </div>
            <div className="flex gap-4 text-sm text-gray-600">
              <a href="#" className="hover:text-blue-600 transition-colors">이용약관</a>
              <a href="#" className="hover:text-blue-600 transition-colors">개인정보처리방침</a>
              <a href="#" className="hover:text-blue-600 transition-colors">문의하기</a>
            </div>
          </div>
        </div>
      </footer>

      {/* Onboarding Modal */}
      <OnboardingModal 
        open={showOnboarding} 
        onComplete={handleOnboardingComplete}
      />
    </div>
  );
}