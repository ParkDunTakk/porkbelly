// OpenAI API 설정 예시
// 이 파일을 openai.ts로 복사하고 실제 API 키를 입력하세요

export const OPENAI_CONFIG = {
  apiKey: "your_openai_api_key_here", // sk-proj-... 형식
  model: "gpt-4o-mini",
  maxTokens: 1000,
  temperature: 0.7
};
