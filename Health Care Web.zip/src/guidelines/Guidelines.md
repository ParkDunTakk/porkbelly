# HealCat Development Guidelines

## Project Overview

**HealCat** is an emotion-aware, AI-powered healthcare web application that adapts to users' feelings and daily situations to provide truly personalized health guidance.

### 🌟 Unique Value Proposition

**"Your health companion that understands how you feel"**

HealCat goes beyond traditional fitness apps by:
- **Emotional Intelligence**: Adjusts workout intensity and type based on your current mood and stress level
- **Situational Awareness**: Recommends different routines when you're tired vs. energetic
- **Adaptive Meal Planning**: Suggests comfort foods when stressed, energizing meals when low on energy
- **Dynamic Scheduling**: Reschedules workout plans based on your daily energy patterns and emotional state

### Core Features (4 Main Features)

1. **Emotion-Aware AI Conversational Interface**
   - Health consultation using OpenAI API with emotional context
   - Adapts tone and recommendations based on user's current mood
   - Comprehensive advice on exercise, nutrition, sleep, and stress management
   - Recognizes patterns in emotional states and provides proactive suggestions

2. **Adaptive Personalized Routine Recommendations**
   - BMI calculation and comprehensive health goal setting
   - **Mood-based workout adjustment**: Light yoga when stressed, high-intensity when energetic
   - **Situation-aware planning**: Different routines for busy days vs. relaxed weekends
   - **Energy pattern recognition**: Morning workouts for early birds, evening for night owls
   - Beginner/Intermediate/Advanced difficulty levels that adapt to daily capacity

3. **Gamification System**
   - Level and XP system
   - Badge collection (locked/unlocked)
   - Challenge and streak tracking
   - Points reward system

4. **Weekly Reports**
   - Water intake, sleep hours, calories, and activity statistics
   - Comprehensive health score visualization using radar charts
   - Insights and achievement summaries

---

## Tech Stack

- **Frontend**: React + TypeScript
- **Styling**: Tailwind CSS v4.0
- **UI Components**: Shadcn/ui
- **Charts**: Recharts
- **Icons**: Lucide React
- **Backend**: Supabase (Database + Auth + Edge Functions)
- **AI**: OpenAI API (called through Supabase Edge Functions)

---

## Project Structure

```
/
├── App.tsx                          # Main application (5 tabs structure)
├── components/
│   ├── ChatInterface.tsx            # AI chat interface
│   ├── OnboardingModal.tsx          # Initial user data input modal
│   ├── RoutineRecommendation.tsx    # Workout routine recommendations
│   ├── GamificationPanel.tsx        # Gamification (levels, badges, challenges)
│   ├── WeeklyReport.tsx             # Weekly health report
│   ├── DailyTracker.tsx             # Daily activity tracking
│   ├── ui/                          # Shadcn UI components
│   └── figma/
│       └── ImageWithFallback.tsx    # Image fallback component
└── styles/
    └── globals.css                  # Global styles
```

---

## Component Descriptions

### 1. App.tsx

- Main application layout
- 5 tabs: AI Chat, Routine Recommendations, Rewards, Weekly Report, Daily Tracker
- Header (logo, notifications, settings, profile) and footer included
- Onboarding modal management

### 2. ChatInterface.tsx

- OpenAI API-based AI assistant
- Message history management
- Quick question buttons
- Real-time loading state
- Mock response logic (uses Supabase Edge Function in production)

### 3. OnboardingModal.tsx

- **Emotion & Context-Based Personalization** - 5-step user onboarding process
  - Step 1: **Physical Profile** - Height/weight input + BMI calculation
  - Step 2: **Health Goals** - Goal selection (weight loss/maintenance/muscle gain/wellness)
  - Step 3: **Emotional State & Energy Patterns** 
    - Current mood (energetic/balanced/tired/stressed)
    - Daily energy patterns (morning person/night owl/varies)
    - Stress level (low/moderate/high)
  - Step 4: **Lifestyle & Preferences**
    - Activity level (sedentary/lightly active/moderately active/very active)
    - Preferred workout time (morning/afternoon/evening/flexible)
    - Exercise environment preference (home/gym/outdoor/any)
  - Step 5: **Motivations & Challenges**
    - Primary motivation (health/appearance/energy/stress relief/sleep quality)
    - Biggest challenge (time/motivation/energy/knowledge/consistency)
    - Dietary preferences (no restriction/vegetarian/vegan/low-carb/other)
- Progress bar showing completion status
- Real-time BMI calculation and category display
- **Adaptive questioning** - Follow-up questions based on emotional state and lifestyle

### 4. RoutineRecommendation.tsx

- 4 workout routines (morning, strength, yoga, cardio)
- Detailed exercise lists for each routine
- Difficulty level, duration, and calorie information
- Expandable/collapsible card UI

### 5. GamificationPanel.tsx

- **Level System**: Current level, XP, total points
- **Badge Collection**: 6 badges (locked/unlocked status)
- **Challenges**: Ongoing challenges with progress bars
- **Streak Tracking**: Consecutive days tracking
- Daily bonus points section

### 6. WeeklyReport.tsx

- **Weekly Summary Cards**: Water, sleep, calories, activity averages
- **Comprehensive Health Score**: Radar chart visualizing 5 areas
- **Detailed Chart Tabs**:
  - Water: Bar Chart
  - Sleep: Area Chart (hours + quality)
  - Calories: Bar Chart (intake vs burned)
  - Activity: Line Chart (steps + active time)
- Insights provided for each tab
- Weekly achievements summary

### 7. DailyTracker.tsx

- **Mood Selection**: Great/Okay/Tired
- **Water Tracking**: 8 glasses goal with visual glass display
- **Sleep Tracking**: Slider for hour input
- **Meal Logging**: Breakfast/lunch/dinner checklist
- Daily summary cards

---

## Data Structures

### User Profile (Supabase)

```typescript
interface UserProfile {
  id: string;
  email: string;
  
  // Physical Profile
  height: number; // cm
  weight: number; // kg
  bmi: number;
  goal: "lose" | "maintain" | "gain" | "wellness";
  
  // Emotional & Energy State
  current_mood: "energetic" | "balanced" | "tired" | "stressed";
  energy_pattern: "morning" | "night" | "varies";
  stress_level: "low" | "moderate" | "high";
  
  // Lifestyle & Preferences
  activity_level: "sedentary" | "lightly_active" | "moderately_active" | "very_active";
  preferred_workout_time: "morning" | "afternoon" | "evening" | "flexible";
  workout_environment: "home" | "gym" | "outdoor" | "any";
  
  // Motivations & Challenges
  primary_motivation: "health" | "appearance" | "energy" | "stress_relief" | "sleep_quality";
  biggest_challenge: "time" | "motivation" | "energy" | "knowledge" | "consistency";
  dietary_preference: "none" | "vegetarian" | "vegan" | "low_carb" | "other";
  
  // Gamification
  level: number;
  xp: number;
  total_points: number;
  streak: number;
  
  // Timestamps
  created_at: timestamp;
  updated_at: timestamp;
}
```

### Daily Activity (Supabase)

```typescript
interface DailyActivity {
  id: string;
  user_id: string;
  date: date;
  
  // Physical Metrics
  water_glasses: number; // Number of water glasses
  sleep_hours: number; // Sleep hours
  sleep_quality: number; // Sleep quality (0-100)
  meals_completed: number; // Number of completed meals
  steps: number; // Step count
  calories_intake: number; // Calories consumed
  calories_burned: number; // Calories burned
  
  // Emotional & Situational Context
  morning_mood: "energetic" | "balanced" | "tired" | "stressed";
  evening_mood: "energetic" | "balanced" | "tired" | "stressed";
  stress_level: "low" | "moderate" | "high";
  energy_level: number; // 1-10 scale
  
  // Workout Adaptation
  workout_completed: boolean;
  workout_type: string; // "cardio", "strength", "yoga", "rest"
  workout_adjusted: boolean; // Was routine adjusted based on mood/energy?
  workout_intensity: "light" | "moderate" | "high";
  
  // Notes
  daily_note: string; // User's reflection on the day
  
  created_at: timestamp;
}
```

### Badges (Supabase)

```typescript
interface Badge {
  id: string;
  name: string;
  description: string;
  icon: string;
  condition: string; // Unlock condition
}

interface UserBadge {
  id: string;
  user_id: string;
  badge_id: string;
  unlocked_at: timestamp;
}
```

### Challenges (Supabase)

```typescript
interface Challenge {
  id: string;
  title: string;
  description: string;
  total: number; // Target value
  points: number; // Reward points
  deadline_days: number; // Deadline
  challenge_type: "weekly" | "daily" | "monthly";
}

interface UserChallenge {
  id: string;
  user_id: string;
  challenge_id: string;
  progress: number;
  completed: boolean;
  started_at: timestamp;
  completed_at?: timestamp;
}
```

---

## Supabase Setup

### Edge Functions

#### 1. openai-chat (Emotion-Aware)

```typescript
// supabase/functions/openai-chat/index.ts
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

serve(async (req) => {
  const { message, history, user_context } = await req.json();
  
  // Get user's emotional and situational context
  const { mood, energy_level, stress_level, time_of_day } = user_context;

  // Build emotion-aware system prompt
  const systemPrompt = `You are HealCat, an empathetic health assistant that adapts to users' emotions and situations.

Current User Context:
- Mood: ${mood}
- Energy Level: ${energy_level}/10
- Stress Level: ${stress_level}
- Time: ${time_of_day}

Guidelines:
- If user is stressed or tired, suggest gentle activities (yoga, walking, breathing exercises)
- If user is energetic, recommend more intense workouts
- Adjust meal suggestions based on emotional state (comfort food when stressed, energizing when tired)
- Be supportive and understanding of their current situation
- Provide actionable, realistic advice that fits their current capacity
- Recognize patterns and suggest preventive measures`;

  const openaiResponse = await fetch(
    "https://api.openai.com/v1/chat/completions",
    {
      method: "POST",
      headers: {
        Authorization: `Bearer ${Deno.env.get("OPENAI_API_KEY")}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "gpt-4",
        messages: [
          {
            role: "system",
            content: systemPrompt,
          },
          ...history,
          { role: "user", content: message },
        ],
      }),
    },
  );

  const data = await openaiResponse.json();
  return new Response(JSON.stringify(data), {
    headers: { "Content-Type": "application/json" },
  });
});
```

#### 2. adaptive-routine-recommendation

```typescript
// supabase/functions/adaptive-routine-recommendation/index.ts
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

serve(async (req) => {
  const { user_id } = await req.json();
  
  const supabase = createClient(
    Deno.env.get("SUPABASE_URL") ?? "",
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
  );

  // Get user profile with emotional context
  const { data: profile } = await supabase
    .from("user_profiles")
    .select("*")
    .eq("id", user_id)
    .single();

  // Get today's activity to check current mood/energy
  const today = new Date().toISOString().split("T")[0];
  const { data: todayActivity } = await supabase
    .from("daily_activities")
    .select("*")
    .eq("user_id", user_id)
    .eq("date", today)
    .single();

  // Adaptive routine logic
  let recommendedRoutine = {
    type: "",
    intensity: "",
    duration: 0,
    exercises: [],
    reason: ""
  };

  const currentMood = todayActivity?.morning_mood || profile.current_mood;
  const energyLevel = todayActivity?.energy_level || 5;

  if (currentMood === "stressed" || profile.stress_level === "high") {
    recommendedRoutine = {
      type: "yoga_meditation",
      intensity: "light",
      duration: 20,
      exercises: ["Breathing exercises", "Gentle stretching", "Meditation"],
      reason: "스트레스 해소를 위한 부드러운 루틴을 추천합니다"
    };
  } else if (currentMood === "tired" || energyLevel < 4) {
    recommendedRoutine = {
      type: "light_cardio",
      intensity: "light",
      duration: 15,
      exercises: ["Walking", "Light stretching", "Easy yoga"],
      reason: "에너지를 보충할 수 있는 가벼운 활동을 추천합니다"
    };
  } else if (currentMood === "energetic" && energyLevel >= 7) {
    recommendedRoutine = {
      type: "high_intensity",
      intensity: "high",
      duration: 45,
      exercises: ["HIIT", "Strength training", "Cardio"],
      reason: "높은 에너지 레벨을 활용한 집중 운동을 추천합니다"
    };
  } else {
    recommendedRoutine = {
      type: "balanced",
      intensity: "moderate",
      duration: 30,
      exercises: ["Moderate cardio", "Core exercises", "Stretching"],
      reason: "균형잡힌 일상 루틴을 추천합니다"
    };
  }

  return new Response(JSON.stringify({ 
    routine: recommendedRoutine,
    user_context: { mood: currentMood, energy: energyLevel }
  }), {
    headers: { "Content-Type": "application/json" },
  });
});
```

#### 3. calculate-weekly-report

```typescript
// supabase/functions/calculate-weekly-report/index.ts
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

serve(async (req) => {
  const { user_id, start_date, end_date } = await req.json();

  const supabase = createClient(
    Deno.env.get("SUPABASE_URL") ?? "",
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "",
  );

  // Fetch user's daily activities for the week
  const { data: activities, error } = await supabase
    .from("daily_activities")
    .select("*")
    .eq("user_id", user_id)
    .gte("date", start_date)
    .lte("date", end_date);

  if (error) {
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 400,
        headers: { "Content-Type": "application/json" },
      },
    );
  }

  // Calculate averages
  const totalDays = activities.length;
  const averages = {
    water:
      activities.reduce((sum, a) => sum + a.water_glasses, 0) /
      totalDays,
    sleep:
      activities.reduce((sum, a) => sum + a.sleep_hours, 0) /
      totalDays,
    caloriesIntake:
      activities.reduce(
        (sum, a) => sum + a.calories_intake,
        0,
      ) / totalDays,
    caloriesBurned:
      activities.reduce(
        (sum, a) => sum + a.calories_burned,
        0,
      ) / totalDays,
    steps:
      activities.reduce((sum, a) => sum + a.steps, 0) /
      totalDays,
  };

  // Generate insights
  const insights = [];
  if (averages.water >= 8) {
    insights.push({
      type: "success",
      message: "Great hydration this week!",
    });
  } else {
    insights.push({
      type: "warning",
      message: "Try to drink more water next week",
    });
  }

  if (averages.sleep >= 7) {
    insights.push({
      type: "success",
      message: "Excellent sleep schedule!",
    });
  } else {
    insights.push({
      type: "warning",
      message: "Consider getting more sleep",
    });
  }

  return new Response(
    JSON.stringify({ averages, insights, activities }),
    {
      headers: { "Content-Type": "application/json" },
    },
  );
});
```

### Row Level Security (RLS) Policies

```sql
-- Users can only read/write their own data
CREATE POLICY "Users can view own profile"
  ON user_profiles FOR SELECT
  USING (auth.uid() = id);

CREATE POLICY "Users can update own profile"
  ON user_profiles FOR UPDATE
  USING (auth.uid() = id);

CREATE POLICY "Users can view own activities"
  ON daily_activities FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own activities"
  ON daily_activities FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own activities"
  ON daily_activities FOR UPDATE
  USING (auth.uid() = user_id);

CREATE POLICY "Users can view own badges"
  ON user_badges FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can view own challenges"
  ON user_challenges FOR SELECT
  USING (auth.uid() = user_id);
```

### Database Tables

```sql
-- User Profiles Table (Enhanced for Emotion-Aware Personalization)
CREATE TABLE user_profiles (
  id UUID REFERENCES auth.users PRIMARY KEY,
  email TEXT NOT NULL,
  
  -- Physical Profile
  height INTEGER,
  weight INTEGER,
  bmi DECIMAL(4,1),
  goal TEXT CHECK (goal IN ('lose', 'maintain', 'gain', 'wellness')),
  
  -- Emotional & Energy State
  current_mood TEXT CHECK (current_mood IN ('energetic', 'balanced', 'tired', 'stressed')),
  energy_pattern TEXT CHECK (energy_pattern IN ('morning', 'night', 'varies')),
  stress_level TEXT CHECK (stress_level IN ('low', 'moderate', 'high')),
  
  -- Lifestyle & Preferences
  activity_level TEXT CHECK (activity_level IN ('sedentary', 'lightly_active', 'moderately_active', 'very_active')),
  preferred_workout_time TEXT CHECK (preferred_workout_time IN ('morning', 'afternoon', 'evening', 'flexible')),
  workout_environment TEXT CHECK (workout_environment IN ('home', 'gym', 'outdoor', 'any')),
  
  -- Motivations & Challenges
  primary_motivation TEXT CHECK (primary_motivation IN ('health', 'appearance', 'energy', 'stress_relief', 'sleep_quality')),
  biggest_challenge TEXT CHECK (biggest_challenge IN ('time', 'motivation', 'energy', 'knowledge', 'consistency')),
  dietary_preference TEXT CHECK (dietary_preference IN ('none', 'vegetarian', 'vegan', 'low_carb', 'other')),
  
  -- Gamification
  level INTEGER DEFAULT 1,
  xp INTEGER DEFAULT 0,
  total_points INTEGER DEFAULT 0,
  streak INTEGER DEFAULT 0,
  
  -- Timestamps
  created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc', NOW()),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc', NOW())
);

-- Daily Activities Table (Enhanced with Emotional Context)
CREATE TABLE daily_activities (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users NOT NULL,
  date DATE NOT NULL,
  
  -- Physical Metrics
  water_glasses INTEGER DEFAULT 0,
  sleep_hours DECIMAL(3,1) DEFAULT 0,
  sleep_quality INTEGER DEFAULT 0,
  meals_completed INTEGER DEFAULT 0,
  steps INTEGER DEFAULT 0,
  calories_intake INTEGER DEFAULT 0,
  calories_burned INTEGER DEFAULT 0,
  
  -- Emotional & Situational Context
  morning_mood TEXT CHECK (morning_mood IN ('energetic', 'balanced', 'tired', 'stressed')),
  evening_mood TEXT CHECK (evening_mood IN ('energetic', 'balanced', 'tired', 'stressed')),
  stress_level TEXT CHECK (stress_level IN ('low', 'moderate', 'high')),
  energy_level INTEGER CHECK (energy_level BETWEEN 1 AND 10),
  
  -- Workout Adaptation
  workout_completed BOOLEAN DEFAULT false,
  workout_type TEXT,
  workout_adjusted BOOLEAN DEFAULT false,
  workout_intensity TEXT CHECK (workout_intensity IN ('light', 'moderate', 'high')),
  
  -- Notes
  daily_note TEXT,
  
  created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc', NOW()),
  UNIQUE(user_id, date)
);

-- Badges Table
CREATE TABLE badges (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  icon TEXT,
  condition TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc', NOW())
);

-- User Badges Table
CREATE TABLE user_badges (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users NOT NULL,
  badge_id UUID REFERENCES badges NOT NULL,
  unlocked_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc', NOW()),
  UNIQUE(user_id, badge_id)
);

-- Challenges Table
CREATE TABLE challenges (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  title TEXT NOT NULL,
  description TEXT,
  total INTEGER NOT NULL,
  points INTEGER DEFAULT 0,
  deadline_days INTEGER,
  challenge_type TEXT CHECK (challenge_type IN ('weekly', 'daily', 'monthly')),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc', NOW())
);

-- User Challenges Table
CREATE TABLE user_challenges (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users NOT NULL,
  challenge_id UUID REFERENCES challenges NOT NULL,
  progress INTEGER DEFAULT 0,
  completed BOOLEAN DEFAULT false,
  started_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc', NOW()),
  completed_at TIMESTAMP WITH TIME ZONE,
  UNIQUE(user_id, challenge_id)
);
```

---

## Development Guide

### 1. Local Development Setup

```bash
# Install packages
npm install

# Supabase local development (optional)
supabase start
supabase functions serve

# Run development server
npm run dev
```

### 2. Environment Variables

```env
VITE_SUPABASE_URL=your_supabase_url
VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
```

### 3. Supabase Client Initialization

```typescript
// lib/supabase.ts
import { createClient } from "@supabase/supabase-js";

export const supabase = createClient(
  import.meta.env.VITE_SUPABASE_URL,
  import.meta.env.VITE_SUPABASE_ANON_KEY,
);
```

### 4. AI Chat Implementation Example

```typescript
// components/ChatInterface.tsx modification
const handleSend = async () => {
  if (!input.trim() || isLoading) return;

  const userMessage: Message = {
    id: Date.now().toString(),
    role: "user",
    content: input,
    timestamp: new Date(),
  };

  setMessages((prev) => [...prev, userMessage]);
  setInput("");
  setIsLoading(true);

  // Call Supabase Edge Function
  const { data, error } = await supabase.functions.invoke(
    "openai-chat",
    {
      body: {
        message: input,
        history: messages.slice(-10).map((m) => ({
          role: m.role,
          content: m.content,
        })),
      },
    },
  );

  if (error) {
    console.error("Error calling OpenAI:", error);
    setIsLoading(false);
    return;
  }

  const aiResponse: Message = {
    id: (Date.now() + 1).toString(),
    role: "assistant",
    content: data.choices[0].message.content,
    timestamp: new Date(),
  };

  setMessages((prev) => [...prev, aiResponse]);
  setIsLoading(false);
};
```

### 5. Emotion-Aware Data Persistence Example

```typescript
// Save daily activity with emotional context
const saveDailyActivity = async (
  activityData: Partial<DailyActivity>,
) => {
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) return;

  const currentHour = new Date().getHours();
  const isMorning = currentHour < 12;

  const { error } = await supabase
    .from("daily_activities")
    .upsert({
      user_id: user.id,
      date: new Date().toISOString().split("T")[0],
      ...activityData,
      // Automatically tag morning or evening mood
      [isMorning ? 'morning_mood' : 'evening_mood']: activityData.current_mood,
    });

  if (error) {
    console.error("Error saving activity:", error);
  } else {
    console.log("Activity saved successfully");
    
    // Check if workout needs adjustment based on mood/energy
    if (activityData.energy_level < 4 || activityData.stress_level === 'high') {
      // Trigger adaptive routine recommendation
      await supabase.functions.invoke('adaptive-routine-recommendation', {
        body: { user_id: user.id }
      });
    }
  }
};

// Update user profile
const updateUserProfile = async (
  profileData: Partial<UserProfile>,
) => {
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) return;

  const { error } = await supabase
    .from("user_profiles")
    .update(profileData)
    .eq("id", user.id);

  if (error) {
    console.error("Error updating profile:", error);
  }
};

// Unlock badge
const unlockBadge = async (badgeId: string) => {
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) return;

  const { error } = await supabase.from("user_badges").insert({
    user_id: user.id,
    badge_id: badgeId,
  });

  if (error) {
    console.error("Error unlocking badge:", error);
  } else {
    // Award points
    await supabase.rpc("increment_points", {
      user_id: user.id,
      points: 100,
    });
  }
};
```

### 6. Database Functions

```sql
-- Increment user points
CREATE OR REPLACE FUNCTION increment_points(user_id UUID, points INTEGER)
RETURNS void AS $$
BEGIN
  UPDATE user_profiles
  SET total_points = total_points + points,
      xp = xp + points
  WHERE id = user_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Update streak
CREATE OR REPLACE FUNCTION update_streak(user_id UUID)
RETURNS void AS $$
DECLARE
  last_activity_date DATE;
  current_streak INTEGER;
BEGIN
  SELECT date INTO last_activity_date
  FROM daily_activities
  WHERE user_id = user_id
  ORDER BY date DESC
  LIMIT 1;

  SELECT streak INTO current_streak
  FROM user_profiles
  WHERE id = user_id;

  IF last_activity_date = CURRENT_DATE - INTERVAL '1 day' THEN
    UPDATE user_profiles
    SET streak = current_streak + 1
    WHERE id = user_id;
  ELSIF last_activity_date < CURRENT_DATE - INTERVAL '1 day' THEN
    UPDATE user_profiles
    SET streak = 1
    WHERE id = user_id;
  END IF;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
```

---

## UI/UX Guidelines

### Color Palette (Blue Theme - Calm & Daily Friendly)

- **Primary**: Blue (#3b82f6) - Main brand color
- **Secondary**: Sky (#60a5fa) - Lighter blue accent
- **Success**: Cyan (#06b6d4) - Achievement highlights
- **Warning**: Amber (#f59e0b) - Alerts
- **Error**: Red (#ef4444) - Errors
- **Background**: Gradient from blue-50 via sky-50 to blue-50
- **Card Backgrounds**: White with blue-tinted borders
- **Accents**: Blue-50 for hover states, Blue-100 for active states

### Typography

- Use Tailwind default fonts
- Sizes are defined in globals.css
- Minimize custom font sizes

### Component Styles

- Cards: Rounded corners (rounded-xl), with shadows
- Buttons: Use gradient for primary actions
- Icons: Lucide React, consistent sizing (w-5 h-5)

### Responsive Design

- Mobile First approach
- Key breakpoints: sm (640px), md (768px), lg (1024px)
- Grid layout: Mobile 1 column → Tablet 2 columns → Desktop 3 columns

---

## Deployment

### Vercel Deployment

```bash
# Install Vercel CLI
npm install -g vercel

# Deploy
vercel

# Set environment variables
vercel env add VITE_SUPABASE_URL
vercel env add VITE_SUPABASE_ANON_KEY
```

### Supabase Production Setup

1. Create project in Supabase Dashboard
2. Create database tables and set up RLS
3. Deploy Edge Functions: `supabase functions deploy`
4. Add OpenAI API Key to Secrets:
   ```bash
   supabase secrets set OPENAI_API_KEY=your_key_here
   ```

---

## Emotion-Aware Personalization Examples

### Example 1: Adaptive Workout Recommendation

**Scenario**: User wakes up feeling stressed (stress_level: high, morning_mood: stressed)

**HealCat's Response**:
```
🐱 "안녕하세요! 오늘 스트레스를 많이 받고 계신 것 같네요.
원래 계획된 고강도 운동 대신, 스트레스 해소에 효과적인 
20분 요가 & 명상 세션을 추천드려요.

추천 루틴:
- 5분: 심호흡 & 스트레칭
- 10분: 부드러운 요가 자세
- 5분: 명상

이 루틴은 코르티솔 수치를 낮추고 마음을 진정시키는데 
도움이 될 거예요. 💚"
```

### Example 2: Context-Aware Meal Suggestion

**Scenario**: User is tired after a long day (evening_mood: tired, energy_level: 3)

**HealCat's Response**:
```
🐱 "피곤한 하루였네요! 에너지를 빠르게 회복할 수 있는 
간단한 저녁 식사를 추천드릴게요.

추천 메뉴:
🥗 연어 샐러드 (오메가-3로 피로 회복)
🍠 고구마 (복합 탄수화물로 지속적인 에너지)
🥑 아보카도 (건강한 지방)

간편 조리법도 함께 알려드릴까요?"
```

### Example 3: Dynamic Schedule Adjustment

**Scenario**: User has been consistently low-energy in the mornings

**HealCat's Response**:
```
🐱 "최근 1주일간 데이터를 분석했어요!
아침 에너지 레벨이 평균 3/10이시네요.

제안:
1. 운동 시간을 저녁 6-7시로 변경하는 건 어떨까요?
   (당신의 에너지 피크 타임대예요!)

2. 아침에는 10분 가벼운 스트레칭만 추천드릴게요.

3. 수면 패턴을 개선하기 위한 취침 루틴도 
   함께 만들어볼까요?

이 변경사항을 적용할까요?"
```

---

## Future Improvements

**Emotion-Aware Features (Priority)**
- [ ] Real-time mood tracking throughout the day
- [ ] Predictive emotional pattern recognition
- [ ] Proactive wellness interventions before burnout
- [ ] Integration with wearable devices for physiological stress markers
- [ ] Voice tone analysis for emotional state detection
- [ ] Personalized comfort food database
- [ ] Emergency stress relief quick-actions

**General Features**
- [ ] Real-time notification system (Supabase Realtime)
- [ ] Social sharing features (with privacy controls)
- [ ] Friend challenges and leaderboards
- [ ] Voice input support
- [ ] Wearable device integration (Fitbit, Apple Watch, Garmin)
- [ ] Multi-language support (i18n)
- [ ] Dark mode
- [ ] PWA support (offline mode)
- [ ] Food scanning with AI (nutrition analysis)
- [ ] Integration with nutrition APIs
- [ ] Workout video library
- [ ] Advanced analytics dashboard with emotional insights
- [ ] Weather-based activity suggestions
- [ ] Menstrual cycle tracking for better workout planning

---

## Testing

### Unit Tests

```bash
# Run tests
npm test

# Run tests with coverage
npm run test:coverage
```

### E2E Tests (Playwright)

```bash
# Install Playwright
npm install -D @playwright/test

# Run E2E tests
npm run test:e2e
```

---

## License & Credits

- UI Components: [Shadcn/ui](https://ui.shadcn.com/)
- Icons: [Lucide](https://lucide.dev/)
- Charts: [Recharts](https://recharts.org/)
- Images: [Unsplash](https://unsplash.com/)

© 2025 HealCat. All rights reserved.